import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { colors } from '../utils/colors';

// Screens
import { SpeakNavigator } from './SpeakNavigator';
import { ScenariosScreen } from '../screens/ScenariosScreen';
import { ProgressScreen } from '../screens/ProgressScreen';
import { SettingsScreen } from '../screens/SettingsScreen';

const Tab = createBottomTabNavigator();

export const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          height: 90,
          backgroundColor: 'transparent',
          borderTopWidth: 0,
          elevation: 0,
        },
        tabBarBackground: () => (
          <BlurView
            intensity={80}
            tint="dark"
            style={{
              flex: 1,
              backgroundColor: 'rgba(10, 10, 15, 0.8)',
              borderTopWidth: 1,
              borderTopColor: colors.glass.border,
            }}
          />
        ),
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          switch (route.name) {
            case 'Speak':
              iconName = focused ? 'mic' : 'mic-outline';
              break;
            case 'Scenarios':
              iconName = focused ? 'briefcase' : 'briefcase-outline';
              break;
            case 'Progress':
              iconName = focused ? 'trending-up' : 'trending-up-outline';
              break;
            case 'Settings':
              iconName = focused ? 'settings' : 'settings-outline';
              break;
            default:
              iconName = 'ellipse';
          }

          return (
            <Ionicons 
              name={iconName} 
              size={size} 
              color={focused ? colors.primary.violet : colors.glass.textSecondary}
              style={{
                shadowColor: focused ? colors.primary.violet : 'transparent',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.5,
                shadowRadius: 4,
              }}
            />
          );
        },
        tabBarActiveTintColor: colors.primary.violet,
        tabBarInactiveTintColor: colors.glass.textSecondary,
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '600',
          marginBottom: 5,
        },
        tabBarHideOnKeyboard: true,
      })}
    >
      <Tab.Screen 
        name="Speak" 
        component={SpeakNavigator}
        options={{ title: 'Speak' }}
      />
      <Tab.Screen 
        name="Scenarios" 
        component={ScenariosScreen}
        options={{ title: 'Scenarios' }}
      />
      <Tab.Screen 
        name="Progress" 
        component={ProgressScreen}
        options={{ title: 'Progress' }}
      />
      <Tab.Screen 
        name="Settings" 
        component={SettingsScreen}
        options={{ title: 'Settings' }}
      />
    </Tab.Navigator>
  );
};