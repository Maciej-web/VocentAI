import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type SubscriptionPlan = 'free' | 'monthly' | 'yearly';

export interface SubscriptionData {
  plan: SubscriptionPlan;
  isActive: boolean;
  expiresAt?: Date;
  startedAt?: Date;
  sessionsUsed: number;
  monthlySessionsUsed: number;
  lastSessionReset: Date;
}

export interface PlanFeatures {
  name: string;
  price: string;
  billing: string;
  sessionsPerMonth: number | 'unlimited';
  features: string[];
  isPopular?: boolean;
}

export const PLANS: Record<SubscriptionPlan, PlanFeatures> = {
  free: {
    name: 'Free',
    price: '0€',
    billing: 'kostenlos',
    sessionsPerMonth: 2,
    features: [
      '2 Sessions pro Monat',
      'Basis KI-Training',
      'Einfache Szenarien',
      'Grundlegendes Feedback',
    ],
  },
  monthly: {
    name: 'Pro Monthly',
    price: '16,99€',
    billing: 'pro Monat',
    sessionsPerMonth: 'unlimited',
    features: [
      'Unbegrenzte Sessions',
      'Erweiterte KI-Modi',
      'Alle Szenarien',
      'Detailliertes Feedback',
      'Fortschritts-Analytics',
      'Prioritätssupport',
    ],
    isPopular: true,
  },
  yearly: {
    name: 'Pro Yearly',
    price: '9,99€',
    billing: 'pro Monat (jährlich abgerechnet)',
    sessionsPerMonth: 'unlimited',
    features: [
      'Unbegrenzte Sessions',
      'Erweiterte KI-Modi',
      'Alle Szenarien',
      'Detailliertes Feedback',
      'Fortschritts-Analytics',
      'Prioritätssupport',
      '40% Ersparnis vs. Monthly',
    ],
  },
};

interface SubscriptionState {
  subscription: SubscriptionData;
  
  // Actions
  initializeSubscription: () => void;
  useSession: () => boolean;
  canUseSession: () => boolean;
  getRemainingSessionsThisMonth: () => number;
  upgradeSubscription: (plan: SubscriptionPlan) => void;
  cancelSubscription: () => void;
  resetMonthlyUsage: () => void;
  
  // UI State
  showPaywall: boolean;
  setShowPaywall: (show: boolean) => void;
}

export const useSubscriptionStore = create<SubscriptionState>()(
  persist(
    (set, get) => ({
      subscription: {
        plan: 'free',
        isActive: true,
        sessionsUsed: 0,
        monthlySessionsUsed: 0,
        lastSessionReset: new Date(),
      },
      showPaywall: false,

      initializeSubscription: () => {
        const state = get();
        const now = new Date();
        const lastReset = new Date(state.subscription.lastSessionReset);
        
        // Reset monthly sessions if it's a new month
        if (now.getMonth() !== lastReset.getMonth() || now.getFullYear() !== lastReset.getFullYear()) {
          set((state) => ({
            subscription: {
              ...state.subscription,
              monthlySessionsUsed: 0,
              lastSessionReset: now,
            },
          }));
        }
      },

      useSession: () => {
        const state = get();
        
        if (!state.canUseSession()) {
          set({ showPaywall: true });
          return false;
        }

        set((state) => ({
          subscription: {
            ...state.subscription,
            sessionsUsed: state.subscription.sessionsUsed + 1,
            monthlySessionsUsed: state.subscription.monthlySessionsUsed + 1,
          },
        }));
        
        return true;
      },

      canUseSession: () => {
        const state = get();
        const { subscription } = state;
        
        // Pro users have unlimited sessions
        if (subscription.plan !== 'free' && subscription.isActive) {
          return true;
        }
        
        // Free users have monthly limit
        const freeMonthlyLimit = PLANS.free.sessionsPerMonth as number;
        return subscription.monthlySessionsUsed < freeMonthlyLimit;
      },

      getRemainingSessionsThisMonth: () => {
        const state = get();
        const { subscription } = state;
        
        if (subscription.plan !== 'free' && subscription.isActive) {
          return Infinity; // Unlimited
        }
        
        const freeMonthlyLimit = PLANS.free.sessionsPerMonth as number;
        return Math.max(0, freeMonthlyLimit - subscription.monthlySessionsUsed);
      },

      upgradeSubscription: (plan: SubscriptionPlan) => {
        const now = new Date();
        const expiresAt = new Date();
        
        if (plan === 'monthly') {
          expiresAt.setMonth(expiresAt.getMonth() + 1);
        } else if (plan === 'yearly') {
          expiresAt.setFullYear(expiresAt.getFullYear() + 1);
        }

        set((state) => ({
          subscription: {
            ...state.subscription,
            plan,
            isActive: plan !== 'free',
            startedAt: now,
            expiresAt: plan !== 'free' ? expiresAt : undefined,
          },
          showPaywall: false,
        }));
      },

      cancelSubscription: () => {
        set((state) => ({
          subscription: {
            ...state.subscription,
            plan: 'free',
            isActive: true,
            expiresAt: undefined,
            startedAt: undefined,
          },
        }));
      },

      resetMonthlyUsage: () => {
        set((state) => ({
          subscription: {
            ...state.subscription,
            monthlySessionsUsed: 0,
            lastSessionReset: new Date(),
          },
        }));
      },

      setShowPaywall: (show: boolean) => {
        set({ showPaywall: show });
      },
    }),
    {
      name: 'vocent-subscription',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        subscription: state.subscription,
      }),
    }
  )
);