import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface SessionData {
  id: string;
  date: Date;
  type: 'practice' | 'coaching';
  scenario: string;
  duration: number;
  score?: number;
  transcript: string;
  feedback?: string;
  isBookmarked: boolean;
}

export interface ProgressData {
  totalSessions: number;
  totalMinutes: number;
  averageScore: number;
  streak: number;
  skillProgress: {
    name: string;
    current: number;
    target: number;
  }[];
}

interface SessionState {
  // Sessions
  sessions: SessionData[];
  addSession: (session: Omit<SessionData, 'id'>) => void;
  updateSession: (id: string, updates: Partial<SessionData>) => void;
  toggleBookmark: (id: string) => void;
  
  // Progress
  progress: ProgressData;
  updateProgress: (updates: Partial<ProgressData>) => void;
  
  // Current session
  currentSession: {
    id: string | null;
    messages: any[];
    isActive: boolean;
  };
  startSession: (type: 'practice' | 'coaching', scenario: string) => void;
  endSession: () => void;
  addMessage: (message: any) => void;
}

export const useSessionStore = create<SessionState>()(
  persist(
    (set, get) => ({
      // Initial state
      sessions: [],
      progress: {
        totalSessions: 0,
        totalMinutes: 0,
        averageScore: 0,
        streak: 0,
        skillProgress: [
          { name: 'Kommunikation', current: 7.0, target: 9.0 },
          { name: 'Überzeugungskraft', current: 6.5, target: 8.5 },
          { name: 'Struktur', current: 6.0, target: 8.0 },
          { name: 'Selbstvertrauen', current: 7.2, target: 9.0 },
        ],
      },
      currentSession: {
        id: null,
        messages: [],
        isActive: false,
      },

      // Actions
      addSession: (sessionData) => {
        const newSession: SessionData = {
          ...sessionData,
          id: `session_${Date.now()}`,
          date: new Date(),
        };

        set((state) => {
          const newSessions = [newSession, ...state.sessions];
          const totalSessions = newSessions.length;
          const totalMinutes = newSessions.reduce((sum, s) => sum + s.duration, 0);
          const averageScore = newSessions
            .filter(s => s.score)
            .reduce((sum, s, _, arr) => sum + (s.score || 0) / arr.length, 0);

          return {
            sessions: newSessions,
            progress: {
              ...state.progress,
              totalSessions,
              totalMinutes,
              averageScore: Math.round(averageScore * 10) / 10,
            },
          };
        });
      },

      updateSession: (id, updates) => {
        set((state) => ({
          sessions: state.sessions.map(session =>
            session.id === id ? { ...session, ...updates } : session
          ),
        }));
      },

      toggleBookmark: (id) => {
        set((state) => ({
          sessions: state.sessions.map(session =>
            session.id === id ? { ...session, isBookmarked: !session.isBookmarked } : session
          ),
        }));
      },

      updateProgress: (updates) => {
        set((state) => ({
          progress: { ...state.progress, ...updates },
        }));
      },

      startSession: (type, scenario) => {
        set({
          currentSession: {
            id: `session_${Date.now()}`,
            messages: [],
            isActive: true,
          },
        });
      },

      endSession: () => {
        set({
          currentSession: {
            id: null,
            messages: [],
            isActive: false,
          },
        });
      },

      addMessage: (message) => {
        set((state) => ({
          currentSession: {
            ...state.currentSession,
            messages: [...state.currentSession.messages, message],
          },
        }));
      },
    }),
    {
      name: 'vocent-sessions',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        sessions: state.sessions,
        progress: state.progress,
      }),
    }
  )
);