// Vocent AI - Glassmorphic Color System
export const colors = {
  // Primary Brand Colors (based on logo)
  primary: {
    violet: '#8B5CF6', // main violet
    blue: '#3B82F6',   // main blue
    turquoise: '#06B6D4', // main turquoise
    purple: '#A855F7',  // secondary purple
  },
  
  // Glassmorphic Colors
  glass: {
    background: 'rgba(139, 92, 246, 0.05)', // very subtle violet tint
    border: 'rgba(255, 255, 255, 0.1)',
    text: 'rgba(255, 255, 255, 0.9)',
    textSecondary: 'rgba(255, 255, 255, 0.7)',
    overlay: 'rgba(0, 0, 0, 0.3)',
  },
  
  // Dark background
  background: {
    primary: '#0A0A0F', // very dark blue-black
    secondary: '#1A1A2E', // slightly lighter
    gradient: {
      start: '#0A0A0F',
      middle: '#1A1A2E', 
      end: '#16213E',
    }
  },
  
  // Status colors
  status: {
    success: '#10B981',
    warning: '#F59E0B',
    error: '#EF4444',
    info: '#3B82F6',
  }
};

// Glassmorphic styles helper
export const glassStyles = {
  card: {
    backgroundColor: colors.glass.background,
    borderColor: colors.glass.border,
    borderWidth: 1,
    borderRadius: 16,
    // Shadow will be handled by style prop due to platform differences
  },
  
  button: {
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    borderColor: colors.glass.border,
    borderWidth: 1,
    borderRadius: 12,
  },
  
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderColor: colors.glass.border,
    borderWidth: 1,
    borderRadius: 8,
  }
};