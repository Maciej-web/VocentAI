import React from 'react';
import { Pressable, Text, PressableProps } from 'react-native';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../utils/colors';
import { cn } from '../utils/cn';

interface GlassButtonProps extends PressableProps {
  title?: string;
  variant?: 'primary' | 'secondary' | 'danger';
  size?: 'small' | 'medium' | 'large';
  icon?: keyof typeof Ionicons.glyphMap;
  iconPosition?: 'left' | 'right';
  className?: string;
  textClassName?: string;
  loading?: boolean;
}

export const GlassButton: React.FC<GlassButtonProps> = ({
  title,
  variant = 'primary',
  size = 'medium',
  icon,
  iconPosition = 'left',
  className,
  textClassName,
  loading = false,
  style,
  children,
  ...props
}) => {
  const getVariantColors = () => {
    switch (variant) {
      case 'primary':
        return {
          bg: 'rgba(139, 92, 246, 0.2)',
          border: colors.primary.violet,
          text: colors.glass.text,
          glow: colors.primary.violet,
        };
      case 'secondary':
        return {
          bg: 'rgba(59, 130, 246, 0.2)',
          border: colors.primary.blue,
          text: colors.glass.text,
          glow: colors.primary.blue,
        };
      case 'danger':
        return {
          bg: 'rgba(239, 68, 68, 0.2)',
          border: colors.status.error,
          text: colors.glass.text,
          glow: colors.status.error,
        };
      default:
        return {
          bg: colors.glass.background,
          border: colors.glass.border,
          text: colors.glass.text,
          glow: colors.primary.violet,
        };
    }
  };

  const getSizeStyles = () => {
    switch (size) {
      case 'small':
        return { padding: 8, fontSize: 14, iconSize: 16 };
      case 'large':
        return { padding: 16, fontSize: 18, iconSize: 24 };
      default:
        return { padding: 12, fontSize: 16, iconSize: 20 };
    }
  };

  const variantColors = getVariantColors();
  const sizeStyles = getSizeStyles();

  const content = children || (
    <>
      {icon && iconPosition === 'left' && (
        <Ionicons 
          name={icon} 
          size={sizeStyles.iconSize} 
          color={variantColors.text} 
          style={{ marginRight: title ? 8 : 0 }}
        />
      )}
      {title && (
        <Text 
          style={[
            { 
              color: variantColors.text, 
              fontSize: sizeStyles.fontSize,
              fontWeight: '600',
            }
          ]}
          className={cn('text-center', textClassName)}
        >
          {title}
        </Text>
      )}
      {icon && iconPosition === 'right' && (
        <Ionicons 
          name={icon} 
          size={sizeStyles.iconSize} 
          color={variantColors.text}
          style={{ marginLeft: title ? 8 : 0 }}
        />
      )}
    </>
  );

  return (
    <Pressable
      style={({ pressed }) => [
        {
          borderRadius: 12,
          overflow: 'hidden',
          borderWidth: 1,
          borderColor: variantColors.border,
          backgroundColor: variantColors.bg,
          shadowColor: variantColors.glow,
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: pressed ? 0.3 : 0.15,
          shadowRadius: pressed ? 12 : 6,
          elevation: pressed ? 12 : 6,
          transform: [{ scale: pressed ? 0.98 : 1 }],
          opacity: loading || props.disabled ? 0.6 : 1,
        },
        style
      ]}
      className={cn('flex-row items-center justify-center', className)}
      disabled={loading || props.disabled}
      {...props}
    >
      <BlurView
        intensity={15}
        tint="dark"
        style={{
          flex: 1,
          padding: sizeStyles.padding,
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'row',
        }}
      >
        {loading ? (
          <Ionicons 
            name="ellipse" 
            size={sizeStyles.iconSize} 
            color={variantColors.text}
          />
        ) : content}
      </BlurView>
    </Pressable>
  );
};