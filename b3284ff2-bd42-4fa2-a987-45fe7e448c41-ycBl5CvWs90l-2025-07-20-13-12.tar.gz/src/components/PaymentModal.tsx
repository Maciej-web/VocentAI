import React, { useState } from 'react';
import { View, Text, ScrollView, Modal, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { AppBackground } from './AppBackground';
import { GlassCard } from './GlassCard';
import { GlassButton } from './GlassButton';
import { VocentLogo } from './VocentLogo';
import { colors } from '../utils/colors';
import { useSubscriptionStore, PLANS, SubscriptionPlan } from '../state/subscriptionStore';

interface PaymentModalProps {
  visible: boolean;
  onClose: () => void;
  onPlanSelected?: (plan: SubscriptionPlan) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  visible,
  onClose,
  onPlanSelected,
}) => {
  const insets = useSafeAreaInsets();
  const { upgradeSubscription, subscription } = useSubscriptionStore();
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan>('monthly');
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePlanSelect = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
  };

  const handleUpgrade = async () => {
    if (selectedPlan === 'free') return;
    
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    upgradeSubscription(selectedPlan);
    onPlanSelected?.(selectedPlan);
    setIsProcessing(false);
    onClose();
  };

  const PlanCard = ({ planKey, plan }: { planKey: SubscriptionPlan; plan: typeof PLANS.free }) => {
    const isSelected = selectedPlan === planKey;
    const isCurrent = subscription.plan === planKey;
    
    return (
      <Pressable onPress={() => handlePlanSelect(planKey)} style={{ marginBottom: 16 }}>
        <GlassCard 
          style={{
            borderColor: isSelected ? colors.primary.violet : colors.glass.border,
            borderWidth: isSelected ? 2 : 1,
            position: 'relative',
          }}
        >
          {plan.isPopular && (
            <View 
              style={{
                position: 'absolute',
                top: -10,
                right: 20,
                backgroundColor: colors.primary.violet,
                paddingHorizontal: 12,
                paddingVertical: 4,
                borderRadius: 12,
                zIndex: 1,
              }}
            >
              <Text 
                style={{
                  color: 'white',
                  fontSize: 12,
                  fontWeight: '600',
                }}
              >
                BELIEBT
              </Text>
            </View>
          )}

          <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16 }}>
            <View style={{ flex: 1 }}>
              <Text 
                style={{
                  color: colors.glass.text,
                  fontSize: 20,
                  fontWeight: 'bold',
                  marginBottom: 4,
                }}
              >
                {plan.name}
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 14,
                }}
              >
                {plan.billing}
              </Text>
            </View>
            
            <View style={{ alignItems: 'flex-end' }}>
              <Text 
                style={{
                  color: colors.primary.violet,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                {plan.price}
              </Text>
              {planKey === 'yearly' && (
                <Text 
                  style={{
                    color: colors.status.success,
                    fontSize: 12,
                    fontWeight: '600',
                  }}
                >
                  40% Rabatt
                </Text>
              )}
            </View>
          </View>

          <View style={{ marginBottom: 16 }}>
            {plan.features.map((feature, index) => (
              <View key={index} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                <Ionicons 
                  name="checkmark-circle" 
                  size={18} 
                  color={colors.status.success}
                  style={{ marginRight: 12 }}
                />
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 14,
                    flex: 1,
                    lineHeight: 20,
                  }}
                >
                  {feature}
                </Text>
              </View>
            ))}
          </View>

          {isCurrent && (
            <View 
              style={{
                backgroundColor: 'rgba(16, 185, 129, 0.2)',
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 8,
                alignItems: 'center',
              }}
            >
              <Text 
                style={{
                  color: colors.status.success,
                  fontSize: 12,
                  fontWeight: '600',
                }}
              >
                Aktueller Plan
              </Text>
            </View>
          )}

          {isSelected && !isCurrent && (
            <View 
              style={{
                backgroundColor: 'rgba(139, 92, 246, 0.2)',
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 8,
                alignItems: 'center',
              }}
            >
              <Text 
                style={{
                  color: colors.primary.violet,
                  fontSize: 12,
                  fontWeight: '600',
                }}
              >
                Ausgewählt
              </Text>
            </View>
          )}
        </GlassCard>
      </Pressable>
    );
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
    >
      <AppBackground variant="glow">
        <View 
          style={{
            paddingTop: insets.top + 20,
            paddingHorizontal: 20,
            paddingBottom: insets.bottom + 20,
            flex: 1,
          }}
        >
          {/* Header */}
          <View style={{ marginBottom: 24 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
                <VocentLogo size={32} style={{ marginRight: 12 }} />
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 24,
                    fontWeight: 'bold',
                  }}
                >
                  Upgrade zu Pro
                </Text>
              </View>
              
              <GlassButton
                icon="close"
                size="small"
                variant="secondary"
                onPress={onClose}
              />
            </View>
            
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 16,
                textAlign: 'center',
                lineHeight: 22,
              }}
            >
              Schalte unbegrenzte Sessions frei
            </Text>
          </View>

          {/* Limit Warning */}
          <GlassCard style={{ marginBottom: 24 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View 
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: 'rgba(245, 158, 11, 0.2)',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: 16,
                }}
              >
                <Ionicons 
                  name="warning" 
                  size={20} 
                  color={colors.status.warning}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 16,
                    fontWeight: '600',
                    marginBottom: 4,
                  }}
                >
                  Sessions-Limit erreicht
                </Text>
                <Text 
                  style={{
                    color: colors.glass.textSecondary,
                    fontSize: 14,
                  }}
                >
                  Sie haben Ihre 2 kostenlosen Sessions diesen Monat aufgebraucht
                </Text>
              </View>
            </View>
          </GlassCard>

          <ScrollView 
            showsVerticalScrollIndicator={false}
            style={{ flex: 1 }}
          >
            {/* Plans */}
            <PlanCard planKey="monthly" plan={PLANS.monthly} />
            <PlanCard planKey="yearly" plan={PLANS.yearly} />

            {/* Free Plan for Reference */}
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 16,
                fontWeight: '600',
                marginTop: 20,
                marginBottom: 16,
                textAlign: 'center',
              }}
            >
              Oder bleiben Sie kostenlos
            </Text>
            <PlanCard planKey="free" plan={PLANS.free} />
          </ScrollView>

          {/* Action Buttons */}
          <View style={{ marginTop: 24 }}>
            {selectedPlan !== 'free' && (
              <GlassButton
                title={isProcessing ? 'Verarbeitung...' : `${PLANS[selectedPlan].name} wählen`}
                icon={isProcessing ? 'ellipse' : 'card'}
                variant="primary"
                loading={isProcessing}
                onPress={handleUpgrade}
                style={{ marginBottom: 12 }}
              />
            )}
            
            <GlassButton
              title="Vielleicht später"
              icon="time"
              variant="secondary"
              onPress={onClose}
            />

            {/* Terms */}
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 12,
                textAlign: 'center',
                marginTop: 16,
                lineHeight: 16,
              }}
            >
              Mit dem Upgrade stimmen Sie unseren Nutzungsbedingungen zu.{'\n'}
              Jederzeit kündbar.
            </Text>
          </View>
        </View>
      </AppBackground>
    </Modal>
  );
};