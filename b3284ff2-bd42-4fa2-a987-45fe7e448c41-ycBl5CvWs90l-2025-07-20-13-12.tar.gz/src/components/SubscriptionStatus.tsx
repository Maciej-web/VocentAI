import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { GlassCard } from './GlassCard';
import { GlassButton } from './GlassButton';
import { colors } from '../utils/colors';
import { useSubscriptionStore, PLANS } from '../state/subscriptionStore';

interface SubscriptionStatusProps {
  onUpgradePress?: () => void;
}

export const SubscriptionStatus: React.FC<SubscriptionStatusProps> = ({ onUpgradePress }) => {
  const { subscription, getRemainingSessionsThisMonth } = useSubscriptionStore();
  const remainingSessions = getRemainingSessionsThisMonth();
  const isFreePlan = subscription.plan === 'free';
  const currentPlan = PLANS[subscription.plan];

  if (!isFreePlan) {
    // Pro user status - Premium design
    return (
      <GlassCard>
        <LinearGradient
          colors={['rgba(139, 92, 246, 0.1)', 'rgba(59, 130, 246, 0.05)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            borderRadius: 12,
            padding: 16,
            margin: -16,
          }}
        >
          {/* Premium Badge */}
          <View style={{ 
            flexDirection: 'row', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            marginBottom: 16 
          }}>
            <View style={{
              backgroundColor: 'rgba(139, 92, 246, 0.2)',
              paddingHorizontal: 12,
              paddingVertical: 4,
              borderRadius: 20,
              flexDirection: 'row',
              alignItems: 'center',
            }}>
              <Ionicons 
                name="star" 
                size={14} 
                color={colors.primary.violet}
                style={{ marginRight: 6 }}
              />
              <Text style={{ 
                color: colors.primary.violet, 
                fontSize: 12, 
                fontWeight: '600',
                textTransform: 'uppercase',
                letterSpacing: 0.5,
              }}>
                PRO AKTIV
              </Text>
            </View>
            
            <View style={{
              width: 32,
              height: 32,
              borderRadius: 16,
              backgroundColor: 'rgba(139, 92, 246, 0.3)',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <Ionicons 
                name="infinite" 
                size={18} 
                color={colors.primary.violet}
              />
            </View>
          </View>

          {/* Plan Info */}
          <View style={{ marginBottom: 16 }}>
            <Text style={{
              color: colors.glass.text,
              fontSize: 20,
              fontWeight: 'bold',
              marginBottom: 4,
            }}>
              {currentPlan.name}
            </Text>
            <Text style={{
              color: colors.glass.textSecondary,
              fontSize: 14,
              lineHeight: 20,
            }}>
              Unbegrenzte Sessions • Alle Features • Prioritätssupport
            </Text>
          </View>

          {/* Features Grid */}
          <View style={{ 
            flexDirection: 'row', 
            justifyContent: 'space-between',
            backgroundColor: 'rgba(255, 255, 255, 0.05)',
            borderRadius: 8,
            padding: 12,
          }}>
            <View style={{ alignItems: 'center', flex: 1 }}>
              <Ionicons name="infinite" size={20} color={colors.primary.violet} />
              <Text style={{ 
                color: colors.glass.text, 
                fontSize: 12, 
                fontWeight: '600',
                marginTop: 4,
              }}>
                Sessions
              </Text>
            </View>
            <View style={{ alignItems: 'center', flex: 1 }}>
              <Ionicons name="trending-up" size={20} color={colors.primary.blue} />
              <Text style={{ 
                color: colors.glass.text, 
                fontSize: 12, 
                fontWeight: '600',
                marginTop: 4,
              }}>
                Analytics
              </Text>
            </View>
            <View style={{ alignItems: 'center', flex: 1 }}>
              <Ionicons name="headset" size={20} color={colors.primary.turquoise} />
              <Text style={{ 
                color: colors.glass.text, 
                fontSize: 12, 
                fontWeight: '600',
                marginTop: 4,
              }}>
                Support
              </Text>
            </View>
          </View>
        </LinearGradient>
      </GlassCard>
    );
  }

  // Free user status - Enhanced design
  const isLimitReached = remainingSessions === 0;
  const usagePercentage = ((2 - remainingSessions) / 2) * 100;
  
  return (
    <GlassCard>
      {/* Header with Plan Badge */}
      <View style={{ 
        flexDirection: 'row', 
        alignItems: 'center', 
        justifyContent: 'space-between',
        marginBottom: 16 
      }}>
        <View style={{
          backgroundColor: isLimitReached 
            ? 'rgba(245, 158, 11, 0.2)' 
            : 'rgba(16, 185, 129, 0.2)',
          paddingHorizontal: 12,
          paddingVertical: 4,
          borderRadius: 20,
          flexDirection: 'row',
          alignItems: 'center',
        }}>
          <Ionicons 
            name={isLimitReached ? "warning" : "gift"} 
            size={14} 
            color={isLimitReached ? colors.status.warning : colors.status.success}
            style={{ marginRight: 6 }}
          />
          <Text style={{ 
            color: isLimitReached ? colors.status.warning : colors.status.success, 
            fontSize: 12, 
            fontWeight: '600',
            textTransform: 'uppercase',
            letterSpacing: 0.5,
          }}>
            FREE PLAN
          </Text>
        </View>
        
        <Text style={{
          color: colors.primary.violet,
          fontSize: 18,
          fontWeight: 'bold',
        }}>
          {remainingSessions}/2
        </Text>
      </View>

      {/* Usage Info */}
      <View style={{ marginBottom: 16 }}>
        <Text style={{
          color: colors.glass.text,
          fontSize: 18,
          fontWeight: '600',
          marginBottom: 4,
        }}>
          {isLimitReached 
            ? 'Sessions aufgebraucht' 
            : `${remainingSessions} Sessions übrig`
          }
        </Text>
        <Text style={{
          color: colors.glass.textSecondary,
          fontSize: 14,
          lineHeight: 20,
        }}>
          {isLimitReached 
            ? 'Upgrade zu Pro für unbegrenzte Sessions'
            : 'Diesen Monat verbleibend • Upgrade für mehr'
          }
        </Text>
      </View>

      {/* Enhanced Progress Section */}
      <View style={{
        backgroundColor: 'rgba(255, 255, 255, 0.03)',
        borderRadius: 12,
        padding: 16,
        marginBottom: 16,
      }}>
        {/* Progress Label */}
        <View style={{ 
          flexDirection: 'row', 
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 8,
        }}>
          <Text style={{
            color: colors.glass.textSecondary,
            fontSize: 12,
            fontWeight: '500',
          }}>
            Monatsverbrauch
          </Text>
          <Text style={{
            color: colors.glass.text,
            fontSize: 12,
            fontWeight: '600',
          }}>
            {usagePercentage.toFixed(0)}%
          </Text>
        </View>

        {/* Progress Bar with Gradient */}
        <View style={{
          height: 8,
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          borderRadius: 4,
          overflow: 'hidden',
        }}>
          <LinearGradient
            colors={
              isLimitReached 
                ? [colors.status.warning, colors.status.error]
                : [colors.status.success, colors.primary.turquoise]
            }
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={{
              height: '100%',
              width: `${usagePercentage}%`,
              borderRadius: 4,
            }}
          />
        </View>

        {/* Progress Indicators */}
        <View style={{ 
          flexDirection: 'row', 
          justifyContent: 'space-between',
          marginTop: 8,
        }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={{
              width: 8,
              height: 8,
              borderRadius: 4,
              backgroundColor: isLimitReached ? colors.status.error : colors.status.success,
              marginRight: 6,
            }} />
            <Text style={{ 
              color: colors.glass.textSecondary, 
              fontSize: 11,
            }}>
              Verwendet: {2 - remainingSessions}
            </Text>
          </View>
          <Text style={{ 
            color: colors.glass.textSecondary, 
            fontSize: 11,
          }}>
            Verfügbar: {remainingSessions}
          </Text>
        </View>
      </View>

      {/* Action Button */}
      {isLimitReached ? (
        <LinearGradient
          colors={[colors.primary.violet, colors.primary.blue]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={{ borderRadius: 12 }}
        >
          <Pressable
            onPress={onUpgradePress}
            style={({ pressed }) => ({
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              paddingVertical: 12,
              paddingHorizontal: 20,
              borderRadius: 12,
              opacity: pressed ? 0.8 : 1,
            })}
          >
            <Ionicons 
              name="rocket" 
              size={18} 
              color="white"
              style={{ marginRight: 8 }}
            />
            <Text style={{
              color: 'white',
              fontSize: 16,
              fontWeight: '600',
            }}>
              Jetzt zu Pro upgraden
            </Text>
          </Pressable>
        </LinearGradient>
      ) : (
        <Pressable 
          onPress={onUpgradePress}
          style={({ pressed }) => ({
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            paddingVertical: 12,
            backgroundColor: 'rgba(139, 92, 246, 0.1)',
            borderRadius: 12,
            borderWidth: 1,
            borderColor: 'rgba(139, 92, 246, 0.3)',
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Ionicons 
            name="star-outline" 
            size={16} 
            color={colors.primary.violet}
            style={{ marginRight: 8 }}
          />
          <Text style={{
            color: colors.primary.violet,
            fontSize: 14,
            fontWeight: '600',
          }}>
            Pro Features entdecken
          </Text>
        </Pressable>
      )}
    </GlassCard>
  );
};