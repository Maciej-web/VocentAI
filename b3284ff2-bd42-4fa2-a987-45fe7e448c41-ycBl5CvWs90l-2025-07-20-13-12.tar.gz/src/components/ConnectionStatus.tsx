import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../utils/colors';
import { GlassCard } from './GlassCard';

interface ConnectionStatusProps {
  status: 'disconnected' | 'connecting' | 'connected' | 'error';
  error?: string;
  onRetry?: () => void;
}

export const ConnectionStatus: React.FC<ConnectionStatusProps> = ({
  status,
  error,
  onRetry,
}) => {
  const getStatusInfo = () => {
    switch (status) {
      case 'connected':
        return {
          icon: 'checkmark-circle' as keyof typeof Ionicons.glyphMap,
          color: colors.status.success,
          text: 'Verbunden mit ElevenLabs AI',
          showRetry: false,
        };
      case 'connecting':
        return {
          icon: 'ellipse' as keyof typeof Ionicons.glyphMap,
          color: colors.status.warning,
          text: 'Verbinde mit ElevenLabs...',
          showRetry: false,
        };
      case 'error':
        return {
          icon: 'warning' as keyof typeof Ionicons.glyphMap,
          color: colors.status.error,
          text: error || 'Verbindungsfehler',
          showRetry: true,
        };
      case 'disconnected':
      default:
        return {
          icon: 'radio-button-off' as keyof typeof Ionicons.glyphMap,
          color: colors.glass.textSecondary,
          text: 'Nicht verbunden',
          showRetry: true,
        };
    }
  };

  const statusInfo = getStatusInfo();

  if (status === 'connected') {
    // Don't show the status card when connected (to save space)
    return null;
  }

  return (
    <GlassCard className="mb-4">
      <View className="flex-row items-center justify-between">
        <View className="flex-row items-center flex-1">
          <View 
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: `${statusInfo.color}20`,
              alignItems: 'center',
              justifyContent: 'center',
              marginRight: 12,
            }}
          >
            <Ionicons 
              name={statusInfo.icon} 
              size={20} 
              color={statusInfo.color}
            />
          </View>
          
          <View className="flex-1">
            <Text 
              style={{
                color: colors.glass.text,
                fontSize: 16,
                fontWeight: '500',
                marginBottom: 2,
              }}
            >
              KI-Verbindung
            </Text>
            <Text 
              style={{
                color: statusInfo.color,
                fontSize: 14,
              }}
            >
              {statusInfo.text}
            </Text>
          </View>
        </View>

        {statusInfo.showRetry && onRetry && (
          <Pressable
            onPress={onRetry}
            style={({ pressed }) => ({
              padding: 8,
              borderRadius: 8,
              backgroundColor: pressed ? 'rgba(255, 255, 255, 0.1)' : 'transparent',
            })}
          >
            <Ionicons 
              name="refresh" 
              size={20} 
              color={colors.primary.violet}
            />
          </Pressable>
        )}
      </View>
    </GlassCard>
  );
};