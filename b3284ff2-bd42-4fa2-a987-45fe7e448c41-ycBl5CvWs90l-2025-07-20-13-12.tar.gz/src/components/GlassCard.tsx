import React from 'react';
import { View, ViewProps } from 'react-native';
import { BlurView } from 'expo-blur';
import { colors, glassStyles } from '../utils/colors';
import { cn } from '../utils/cn';

interface GlassCardProps extends ViewProps {
  children: React.ReactNode;
  intensity?: number;
  className?: string;
  blurTint?: 'light' | 'dark' | 'default';
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  intensity = 20,
  className,
  blurTint = 'dark',
  style,
  ...props
}) => {
  return (
    <BlurView
      intensity={intensity}
      tint={blurTint}
      style={[
        {
          borderRadius: 16,
          overflow: 'hidden',
          borderWidth: 1,
          borderColor: colors.glass.border,
          shadowColor: colors.primary.violet,
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.1,
          shadowRadius: 8,
          elevation: 8,
        },
        style
      ]}
      className={cn('bg-transparent', className)}
      {...props}
    >
      <View 
        style={{
          backgroundColor: colors.glass.background,
          flex: 1,
        }}
        className="p-4"
      >
        {children}
      </View>
    </BlurView>
  );
};