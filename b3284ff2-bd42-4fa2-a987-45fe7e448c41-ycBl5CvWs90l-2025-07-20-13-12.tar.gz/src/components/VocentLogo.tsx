import React from 'react';
import { View, Image, ViewStyle } from 'react-native';

interface VocentLogoProps {
  size?: number;
  style?: ViewStyle;
}

export const VocentLogo: React.FC<VocentLogoProps> = ({ 
  size = 60, 
  style 
}) => {
  return (
    <View style={[{ alignItems: 'center', justifyContent: 'center' }, style]}>
      <Image
        source={require('../../assets/vocent-logo.png')}
        style={{
          width: size,
          height: size,
          resizeMode: 'contain',
        }}
        accessibilityLabel="Vocent AI Logo"
      />
    </View>
  );
};