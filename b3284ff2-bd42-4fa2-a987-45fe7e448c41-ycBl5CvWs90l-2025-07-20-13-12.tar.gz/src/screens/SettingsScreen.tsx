import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';

import { AppBackground } from '../components/AppBackground';
import { GlassCard } from '../components/GlassCard';
import { GlassButton } from '../components/GlassButton';
import { PaymentModal } from '../components/PaymentModal';
import { VocentLogo } from '../components/VocentLogo';
import { colors } from '../utils/colors';
import { useSubscriptionStore, PLANS } from '../state/subscriptionStore';

interface SettingsItemProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle?: string;
  onPress: () => void;
  showArrow?: boolean;
  badge?: string;
  badgeColor?: string;
}

const SettingsItem: React.FC<SettingsItemProps> = ({
  icon,
  title,
  subtitle,
  onPress,
  showArrow = true,
  badge,
  badgeColor = colors.primary.violet,
}) => {
  return (
    <Pressable onPress={onPress}>
      <View 
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          paddingVertical: 16,
          paddingHorizontal: 20,
          borderBottomWidth: 1,
          borderBottomColor: 'rgba(255, 255, 255, 0.05)',
        }}
      >
        <View 
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            backgroundColor: 'rgba(139, 92, 246, 0.2)',
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: 16,
          }}
        >
          <Ionicons 
            name={icon} 
            size={20} 
            color={colors.primary.violet}
          />
        </View>
        
        <View className="flex-1">
          <View className="flex-row items-center">
            <Text 
              style={{
                color: colors.glass.text,
                fontSize: 16,
                fontWeight: '500',
                flex: 1,
              }}
            >
              {title}
            </Text>
            {badge && (
              <View 
                style={{
                  backgroundColor: `${badgeColor}20`,
                  paddingHorizontal: 8,
                  paddingVertical: 2,
                  borderRadius: 10,
                  marginRight: 8,
                }}
              >
                <Text 
                  style={{
                    color: badgeColor,
                    fontSize: 12,
                    fontWeight: '600',
                  }}
                >
                  {badge}
                </Text>
              </View>
            )}
          </View>
          {subtitle && (
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 14,
                marginTop: 2,
              }}
            >
              {subtitle}
            </Text>
          )}
        </View>
        
        {showArrow && (
          <Ionicons 
            name="chevron-forward" 
            size={20} 
            color={colors.glass.textSecondary}
          />
        )}
      </View>
    </Pressable>
  );
};

export const SettingsScreen = () => {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { 
    subscription, 
    getRemainingSessionsThisMonth, 
    cancelSubscription,
  } = useSubscriptionStore();
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  
  const remainingSessions = getRemainingSessionsThisMonth();
  const currentPlan = PLANS[subscription.plan];
  const isFreePlan = subscription.plan === 'free';

  const handleCancelSubscription = () => {
    Alert.alert(
      'Abonnement kündigen',
      'Sind Sie sicher, dass Sie Ihr Abonnement kündigen möchten? Sie werden zum Free Plan zurückgestuft.',
      [
        { text: 'Abbrechen', style: 'cancel' },
        { 
          text: 'Kündigen', 
          style: 'destructive',
          onPress: () => {
            cancelSubscription();
            Alert.alert('Gekündigt', 'Ihr Abonnement wurde erfolgreich gekündigt.');
          }
        },
      ]
    );
  };

  const formatDate = (date?: Date) => {
    if (!date) return '';
    return new Date(date).toLocaleDateString('de-DE');
  };

  return (
    <AppBackground>
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ 
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="flex-row items-center justify-center mb-8">
          <VocentLogo size={40} style={{ marginRight: 12 }} />
          <Text 
            style={{ 
              color: colors.glass.text,
              fontSize: 28,
              fontWeight: 'bold',
            }}
          >
            Settings
          </Text>
        </View>

        {/* Subscription Overview */}
        <GlassCard className="mb-6">
          <View className="flex-row items-center justify-between mb-4">
            <View className="flex-row items-center">
              <View 
                style={{
                  width: 50,
                  height: 50,
                  borderRadius: 25,
                  backgroundColor: isFreePlan 
                    ? 'rgba(16, 185, 129, 0.2)' 
                    : 'rgba(139, 92, 246, 0.2)',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: 16,
                }}
              >
                <Ionicons 
                  name={isFreePlan ? "gift" : "star"} 
                  size={24} 
                  color={isFreePlan ? colors.status.success : colors.primary.violet}
                />
              </View>
              
              <View>
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 20,
                    fontWeight: 'bold',
                    marginBottom: 4,
                  }}
                >
                  {currentPlan.name}
                </Text>
                <Text 
                  style={{
                    color: colors.glass.textSecondary,
                    fontSize: 14,
                  }}
                >
                  {isFreePlan 
                    ? `${remainingSessions}/2 Sessions übrig`
                    : 'Unbegrenzte Sessions'
                  }
                </Text>
              </View>
            </View>

            <View className="items-end">
              <Text 
                style={{
                  color: colors.primary.violet,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                {currentPlan.price}
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 12,
                }}
              >
                {currentPlan.billing}
              </Text>
            </View>
          </View>

          {!isFreePlan && subscription.expiresAt && (
            <View 
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.05)',
                padding: 12,
                borderRadius: 8,
                marginBottom: 16,
              }}
            >
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 12,
                  marginBottom: 4,
                }}
              >
                Läuft ab am:
              </Text>
              <Text 
                style={{
                  color: colors.glass.text,
                  fontSize: 14,
                  fontWeight: '500',
                }}
              >
                {formatDate(subscription.expiresAt)}
              </Text>
            </View>
          )}

          {isFreePlan ? (
            <GlassButton
              title="Zu Pro upgraden"
              icon="rocket"
              variant="primary"
              onPress={() => setShowPaymentModal(true)}
            />
          ) : (
            <View className="space-y-3">
              <GlassButton
                title="Plan ändern"
                icon="swap-horizontal"
                variant="secondary"
                onPress={() => setShowPaymentModal(true)}
              />
            </View>
          )}
        </GlassCard>

        {/* Settings Sections */}
        <GlassCard className="mb-6">
          <Text 
            style={{
              color: colors.glass.text,
              fontSize: 18,
              fontWeight: '600',
              paddingHorizontal: 20,
              paddingTop: 20,
              paddingBottom: 8,
            }}
          >
            Abonnement
          </Text>
          
          <SettingsItem
            icon="card"
            title="Zahlungsmethode"
            subtitle="Kreditkarte verwalten"
            onPress={() => Alert.alert('Info', 'Zahlungsmethoden-Verwaltung kommt bald!')}
          />
          
          <SettingsItem
            icon="receipt"
            title="Rechnungsverlauf"
            subtitle="Vergangene Zahlungen einsehen"
            onPress={() => Alert.alert('Info', 'Rechnungsverlauf kommt bald!')}
          />
          
          {!isFreePlan && (
            <SettingsItem
              icon="close-circle"
              title="Abonnement kündigen"
              subtitle="Zurück zum Free Plan"
              onPress={handleCancelSubscription}
            />
          )}
        </GlassCard>

        <GlassCard className="mb-6">
          <Text 
            style={{
              color: colors.glass.text,
              fontSize: 18,
              fontWeight: '600',
              paddingHorizontal: 20,
              paddingTop: 20,
              paddingBottom: 8,
            }}
          >
            App Einstellungen
          </Text>
          
          <SettingsItem
            icon="notifications"
            title="Benachrichtigungen"
            subtitle="Push-Nachrichten verwalten"
            onPress={() => Alert.alert('Info', 'Benachrichtigungs-Einstellungen kommen bald!')}
          />
          
          <SettingsItem
            icon="language"
            title="Sprache"
            subtitle="Deutsch"
            onPress={() => Alert.alert('Info', 'Sprach-Einstellungen kommen bald!')}
          />
          
          <SettingsItem
            icon="moon"
            title="Erscheinungsbild"
            subtitle="Dark Mode"
            onPress={() => Alert.alert('Info', 'Design-Einstellungen kommen bald!')}
          />
        </GlassCard>

        <GlassCard className="mb-6">
          <Text 
            style={{
              color: colors.glass.text,
              fontSize: 18,
              fontWeight: '600',
              paddingHorizontal: 20,
              paddingTop: 20,
              paddingBottom: 8,
            }}
          >
            Support & Info
          </Text>
          
          <SettingsItem
            icon="help-circle"
            title="Hilfe & FAQ"
            subtitle="Häufig gestellte Fragen"
            onPress={() => Alert.alert('Info', 'Hilfe-Bereich kommt bald!')}
          />
          
          <SettingsItem
            icon="mail"
            title="Kontakt"
            subtitle="Support kontaktieren"
            onPress={() => Alert.alert('Info', 'Kontakt-Formular kommt bald!')}
          />
          
          <SettingsItem
            icon="document-text"
            title="Datenschutz"
            subtitle="Datenschutzerklärung lesen"
            onPress={() => Alert.alert('Info', 'Datenschutzerklärung kommt bald!')}
          />
          
          <SettingsItem
            icon="document"
            title="Nutzungsbedingungen"
            subtitle="AGB lesen"
            onPress={() => Alert.alert('Info', 'Nutzungsbedingungen kommen bald!')}
          />
        </GlassCard>

        {/* App Info */}
        <GlassCard>
          <View className="items-center py-4">
            <VocentLogo size={60} style={{ marginBottom: 12 }} />
            <Text 
              style={{
                color: colors.glass.text,
                fontSize: 20,
                fontWeight: 'bold',
                marginBottom: 4,
              }}
            >
              Vocent AI
            </Text>
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 14,
                marginBottom: 8,
              }}
            >
              Version 1.0.0
            </Text>
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 12,
                textAlign: 'center',
                lineHeight: 18,
              }}
            >
              © 2024 Vocent AI. Alle Rechte vorbehalten.{'\n'}
              Business-Gespräche mit KI trainieren.
            </Text>
          </View>
        </GlassCard>
      </ScrollView>

      {/* Payment Modal */}
      <PaymentModal
        visible={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onPlanSelected={(plan) => {
          console.log('Plan changed to:', plan);
        }}
      />
    </AppBackground>
  );
};