import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';

import { AppBackground } from '../components/AppBackground';
import { GlassCard } from '../components/GlassCard';
import { GlassButton } from '../components/GlassButton';
import { MicrophoneButton } from '../components/MicrophoneButton';
import { colors } from '../utils/colors';
import { createConversation, ConversationMessage, ElevenLabsConversation } from '../api/elevenlabs-mock';

export const PracticeScreen = () => {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const [conversation, setConversation] = useState<ElevenLabsConversation | null>(null);
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentScenario] = useState('Freies Gespräch');

  useEffect(() => {
    initializeConversation();
    return () => {
      conversation?.endConversation();
    };
  }, []);

  const initializeConversation = async () => {
    try {
      const newConversation = createConversation({
        mode: 'practice',
        scenario: 'free-talk',
      });
      
      newConversation.onConnect(() => {
        setIsConnected(true);
      });

      newConversation.onMessage((message) => {
        setMessages(prev => {
          const exists = prev.some(m => m.id === message.id);
          if (exists) {
            return prev.map(m => m.id === message.id ? message : m);
          } else {
            return [...prev, message];
          }
        });
      });

      newConversation.onError((error) => {
        console.error('Conversation error:', error);
        setIsConnected(false);
      });
      
      await newConversation.startConversation();
      setConversation(newConversation);

      // Add welcome message
      const welcomeMessage: ConversationMessage = {
        id: 'welcome',
        timestamp: new Date(),
        type: 'ai',
        text: 'Hallo! Ich bin Ihr KI-Gesprächspartner. Wir können über jedes Business-Thema sprechen. Drücken Sie das Mikrofon und beginnen Sie einfach zu sprechen!',
      };
      setMessages([welcomeMessage]);

    } catch (error) {
      console.error('Failed to initialize conversation:', error);
      setIsConnected(false);
    }
  };

  const handleRecordingStart = () => {
    console.log('Recording started...');
  };

  const handleRecordingStop = async (audioUri: string) => {
    if (!conversation) return;

    try {
      setIsProcessing(true);
      
      // Send audio to mock conversation
      await conversation.sendAudioMessage(audioUri);
      // Messages are updated via the onMessage callback

    } catch (error) {
      console.error('Failed to process audio:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRecordingError = (error: string) => {
    console.error('Recording error:', error);
  };

  const endSession = async () => {
    if (conversation) {
      await conversation.endConversation();
      
      // Save session to store (this is already handled by subscription store)
      // The session was already counted when starting
    }
    navigation.goBack();
  };

  return (
    <AppBackground variant="glow">
      <KeyboardAvoidingView 
        style={{ flex: 1 }} 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {/* Header */}
        <View 
          style={{
            paddingTop: insets.top + 10,
            paddingHorizontal: 20,
            paddingBottom: 20,
          }}
        >
          <View className="flex-row items-center justify-between mb-4">
            <GlassButton
              icon="chevron-back"
              size="small"
              variant="secondary"
              onPress={() => navigation.goBack()}
            />
            
            <View className="flex-1 mx-4">
              <Text 
                style={{
                  color: colors.glass.text,
                  fontSize: 20,
                  fontWeight: '600',
                  textAlign: 'center',
                }}
              >
                Practice Mode
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 14,
                  textAlign: 'center',
                }}
              >
                {currentScenario}
              </Text>
            </View>

            <GlassButton
              icon="close"
              size="small"
              variant="danger"
              onPress={endSession}
            />
          </View>

          {/* Connection Status */}
          <View className="flex-row items-center justify-center">
            <View 
              style={{
                width: 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: isConnected ? colors.status.success : colors.status.error,
                marginRight: 8,
              }}
            />
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 12,
              }}
            >
              {isConnected ? 'Verbunden' : 'Verbindung...'}
            </Text>
          </View>
        </View>

        {/* Conversation Messages */}
        <ScrollView 
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingHorizontal: 20,
            paddingBottom: 20,
          }}
          showsVerticalScrollIndicator={false}
        >
          <View className="space-y-4">
            {messages.map((message) => (
              <View
                key={message.id}
                className={`flex-row ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <View
                  style={{
                    maxWidth: '80%',
                    backgroundColor: message.type === 'ai' 
                      ? colors.glass.background 
                      : 'rgba(139, 92, 246, 0.2)',
                    borderWidth: 1,
                    borderColor: message.type === 'ai' 
                      ? colors.glass.border 
                      : colors.primary.violet,
                    borderRadius: 16,
                    padding: 16,
                  }}
                >
                  <View className="flex-row items-center mb-2">
                    <Ionicons
                      name={message.type === 'ai' ? 'chatbubble' : 'person'}
                      size={16}
                      color={message.type === 'ai' ? colors.primary.turquoise : colors.primary.violet}
                    />
                    <Text 
                      style={{
                        color: colors.glass.textSecondary,
                        fontSize: 12,
                        marginLeft: 8,
                      }}
                    >
                      {message.type === 'ai' ? 'KI-Trainer' : 'Sie'}
                    </Text>
                  </View>
                  
                  <Text 
                    style={{
                      color: colors.glass.text,
                      fontSize: 16,
                      lineHeight: 22,
                    }}
                  >
                    {message.text}
                  </Text>

                  {message.duration && (
                    <Text 
                      style={{
                        color: colors.glass.textSecondary,
                        fontSize: 12,
                        marginTop: 8,
                        textAlign: 'right',
                      }}
                    >
                      {message.duration.toFixed(1)}s
                    </Text>
                  )}
                </View>
              </View>
            ))}

            {isProcessing && (
              <View className="flex-row justify-start">
                <GlassCard>
                  <View className="flex-row items-center">
                    <Ionicons
                      name="ellipse"
                      size={16}
                      color={colors.primary.turquoise}
                    />
                    <Text 
                      style={{
                        color: colors.glass.textSecondary,
                        fontSize: 14,
                        marginLeft: 8,
                      }}
                    >
                      KI-Trainer denkt nach...
                    </Text>
                  </View>
                </GlassCard>
              </View>
            )}
          </View>
        </ScrollView>

        {/* Microphone Controls */}
        <View 
          style={{
            paddingHorizontal: 20,
            paddingBottom: insets.bottom + 100,
            paddingTop: 20,
            alignItems: 'center',
          }}
        >
          <MicrophoneButton
            onRecordingStart={handleRecordingStart}
            onRecordingStop={handleRecordingStop}
            onRecordingError={handleRecordingError}
            disabled={!isConnected || isProcessing}
            size="large"
          />
          
          <Text 
            style={{
              color: colors.glass.textSecondary,
              fontSize: 14,
              textAlign: 'center',
              marginTop: 16,
              lineHeight: 20,
            }}
          >
            {isProcessing 
              ? 'Verarbeite Ihre Nachricht...'
              : 'Tippen Sie das Mikrofon an und sprechen Sie'
            }
          </Text>
        </View>
      </KeyboardAvoidingView>
    </AppBackground>
  );
};