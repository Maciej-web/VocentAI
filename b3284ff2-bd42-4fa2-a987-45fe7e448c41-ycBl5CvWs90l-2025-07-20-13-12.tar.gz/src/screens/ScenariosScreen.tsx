import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { AppBackground } from '../components/AppBackground';
import { GlassCard } from '../components/GlassCard';
import { GlassButton } from '../components/GlassButton';
import { colors } from '../utils/colors';

const scenarios = [
  {
    id: 'job-interviews',
    title: 'Job Interviews',
    icon: 'briefcase' as keyof typeof Ionicons.glyphMap,
    color: colors.primary.violet,
    description: 'Bewerbungsgespräche für verschiedene Positionen',
    subcategories: [
      { id: 'hr-interview', title: 'HR Interview', difficulty: 'Einsteiger' },
      { id: 'tech-interview', title: 'Technical Interview', difficulty: 'Fortgeschritten' },
      { id: 'management-interview', title: 'Management Interview', difficulty: 'Experte' },
    ]
  },
  {
    id: 'negotiations',
    title: 'Verhandlungen',
    icon: 'handshake' as keyof typeof Ionicons.glyphMap,
    color: colors.primary.blue,
    description: 'Geschäftsverhandlungen und Gespräche',
    subcategories: [
      { id: 'salary-negotiation', title: 'Gehaltsverhandlung', difficulty: 'Fortgeschritten' },
      { id: 'contract-negotiation', title: 'Vertragsverhandlung', difficulty: 'Experte' },
      { id: 'client-negotiation', title: 'Kundenverhandlung', difficulty: 'Fortgeschritten' },
    ]
  },
  {
    id: 'presentations',
    title: 'Präsentationen',
    icon: 'easel' as keyof typeof Ionicons.glyphMap,
    color: colors.primary.turquoise,
    description: 'Pitches, Projektpräsentationen und mehr',
    subcategories: [
      { id: 'startup-pitch', title: 'Startup Pitch', difficulty: 'Fortgeschritten' },
      { id: 'project-presentation', title: 'Projektpräsentation', difficulty: 'Einsteiger' },
      { id: 'investor-meeting', title: 'Investor Meeting', difficulty: 'Experte' },
    ]
  },
  {
    id: 'networking',
    title: 'Networking & Konflikte',
    icon: 'people' as keyof typeof Ionicons.glyphMap,
    color: colors.primary.purple,
    description: 'Netzwerken und schwierige Gespräche',
    subcategories: [
      { id: 'networking-event', title: 'Networking Event', difficulty: 'Einsteiger' },
      { id: 'conflict-resolution', title: 'Konfliktlösung', difficulty: 'Fortgeschritten' },
      { id: 'difficult-conversation', title: 'Schwierige Gespräche', difficulty: 'Experte' },
    ]
  },
];

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case 'Einsteiger': return colors.status.success;
    case 'Fortgeschritten': return colors.status.warning;
    case 'Experte': return colors.status.error;
    default: return colors.glass.textSecondary;
  }
};

export const ScenariosScreen = () => {
  const insets = useSafeAreaInsets();
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const toggleCategory = (categoryId: string) => {
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
  };

  return (
    <AppBackground>
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ 
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="mb-8">
          <Text 
            style={{ 
              color: colors.glass.text,
              fontSize: 28,
              fontWeight: 'bold',
              textAlign: 'center',
              marginBottom: 8,
            }}
          >
            Business Scenarios
          </Text>
          <Text 
            style={{ 
              color: colors.glass.textSecondary,
              fontSize: 16,
              textAlign: 'center',
              lineHeight: 24,
            }}
          >
            Wähle ein Szenario für dein Training
          </Text>
        </View>

        {/* Scenario Categories */}
        <View className="space-y-4">
          {scenarios.map((scenario) => (
            <GlassCard key={scenario.id}>
              <Pressable 
                onPress={() => toggleCategory(scenario.id)}
                className="flex-row items-center justify-between mb-2"
              >
                <View className="flex-row items-center flex-1">
                  <View 
                    style={{
                      width: 45,
                      height: 45,
                      borderRadius: 22.5,
                      backgroundColor: `${scenario.color}20`,
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: 16,
                    }}
                  >
                    <Ionicons 
                      name={scenario.icon} 
                      size={24} 
                      color={scenario.color}
                    />
                  </View>
                  <View className="flex-1">
                    <Text 
                      style={{
                        color: colors.glass.text,
                        fontSize: 18,
                        fontWeight: '600',
                        marginBottom: 4,
                      }}
                    >
                      {scenario.title}
                    </Text>
                    <Text 
                      style={{
                        color: colors.glass.textSecondary,
                        fontSize: 14,
                        lineHeight: 18,
                      }}
                    >
                      {scenario.description}
                    </Text>
                  </View>
                </View>
                
                <Ionicons 
                  name={expandedCategory === scenario.id ? 'chevron-up' : 'chevron-down'} 
                  size={20} 
                  color={colors.glass.textSecondary}
                />
              </Pressable>

              {/* Subcategories */}
              {expandedCategory === scenario.id && (
                <View className="mt-4 space-y-3">
                  {scenario.subcategories.map((sub) => (
                    <View 
                      key={sub.id}
                      className="flex-row items-center justify-between p-3 rounded-lg"
                      style={{
                        backgroundColor: 'rgba(255, 255, 255, 0.03)',
                        borderWidth: 1,
                        borderColor: colors.glass.border,
                      }}
                    >
                      <View className="flex-1">
                        <Text 
                          style={{
                            color: colors.glass.text,
                            fontSize: 16,
                            fontWeight: '500',
                            marginBottom: 2,
                          }}
                        >
                          {sub.title}
                        </Text>
                        <View className="flex-row items-center">
                          <View 
                            style={{
                              paddingHorizontal: 8,
                              paddingVertical: 2,
                              borderRadius: 10,
                              backgroundColor: `${getDifficultyColor(sub.difficulty)}20`,
                            }}
                          >
                            <Text 
                              style={{
                                color: getDifficultyColor(sub.difficulty),
                                fontSize: 12,
                                fontWeight: '500',
                              }}
                            >
                              {sub.difficulty}
                            </Text>
                          </View>
                        </View>
                      </View>
                      
                      <GlassButton
                        title="Starten"
                        size="small"
                        variant="primary"
                        onPress={() => {
                          // TODO: Navigate to practice/coaching with selected scenario
                          console.log('Start scenario:', sub.id);
                        }}
                      />
                    </View>
                  ))}
                </View>
              )}
            </GlassCard>
          ))}
        </View>

        {/* Custom Scenario */}
        <GlassCard className="mt-6">
          <View className="items-center">
            <View 
              style={{
                width: 60,
                height: 60,
                borderRadius: 30,
                backgroundColor: 'rgba(139, 92, 246, 0.2)',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: 16,
              }}
            >
              <Ionicons 
                name="add-circle" 
                size={32} 
                color={colors.primary.violet}
              />
            </View>
            
            <Text 
              style={{
                color: colors.glass.text,
                fontSize: 18,
                fontWeight: '600',
                marginBottom: 8,
                textAlign: 'center',
              }}
            >
              Eigenes Szenario
            </Text>
            
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 14,
                textAlign: 'center',
                marginBottom: 16,
                lineHeight: 20,
              }}
            >
              Erstelle ein individuelles Gesprächsszenario
            </Text>
            
            <GlassButton
              title="Szenario erstellen"
              icon="create"
              variant="primary"
              onPress={() => {
                // TODO: Navigate to custom scenario creation
                console.log('Create custom scenario');
              }}
            />
          </View>
        </GlassCard>
      </ScrollView>
    </AppBackground>
  );
};