import React, { useState } from 'react';
import { View, Text, ScrollView, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';

import { AppBackground } from '../components/AppBackground';
import { GlassCard } from '../components/GlassCard';
import { GlassButton } from '../components/GlassButton';
import { PaymentModal } from '../components/PaymentModal';
import { VocentLogo } from '../components/VocentLogo';
import { colors } from '../utils/colors';
import { useSubscriptionStore, PLANS } from '../state/subscriptionStore';

export const SubscriptionScreen = () => {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { 
    subscription, 
    getRemainingSessionsThisMonth, 
    cancelSubscription,
  } = useSubscriptionStore();
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  
  const remainingSessions = getRemainingSessionsThisMonth();
  const currentPlan = PLANS[subscription.plan];
  const isFreePlan = subscription.plan === 'free';

  const formatDate = (date?: Date) => {
    if (!date) return '';
    return new Date(date).toLocaleDateString('de-DE');
  };

  const handleCancelSubscription = () => {
    Alert.alert(
      'Abonnement kündigen',
      'Sind Sie sicher, dass Sie Ihr Abonnement kündigen möchten? Sie werden zum Free Plan zurückgestuft.',
      [
        { text: 'Abbrechen', style: 'cancel' },
        { 
          text: 'Kündigen', 
          style: 'destructive',
          onPress: () => {
            cancelSubscription();
            Alert.alert('Gekündigt', 'Ihr Abonnement wurde erfolgreich gekündigt.');
          }
        },
      ]
    );
  };

  return (
    <AppBackground>
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ 
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="flex-row items-center mb-8">
          <GlassButton
            icon="chevron-back"
            size="small"
            variant="secondary"
            onPress={() => navigation.goBack()}
          />
          <View className="flex-row items-center flex-1 ml-4">
            <VocentLogo size={32} style={{ marginRight: 12 }} />
            <Text 
              style={{ 
                color: colors.glass.text,
                fontSize: 24,
                fontWeight: 'bold',
              }}
            >
              Abonnement
            </Text>
          </View>
        </View>

        {/* Current Plan Status */}
        <GlassCard className="mb-6">
          <View className="flex-row items-center justify-between mb-4">
            <View className="flex-row items-center">
              <View 
                style={{
                  width: 50,
                  height: 50,
                  borderRadius: 25,
                  backgroundColor: isFreePlan 
                    ? 'rgba(16, 185, 129, 0.2)' 
                    : 'rgba(139, 92, 246, 0.2)',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: 16,
                }}
              >
                <Ionicons 
                  name={isFreePlan ? "gift" : "star"} 
                  size={24} 
                  color={isFreePlan ? colors.status.success : colors.primary.violet}
                />
              </View>
              
              <View>
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 20,
                    fontWeight: 'bold',
                    marginBottom: 4,
                  }}
                >
                  {currentPlan.name}
                </Text>
                <Text 
                  style={{
                    color: colors.glass.textSecondary,
                    fontSize: 14,
                  }}
                >
                  {isFreePlan ? 'Kostenloser Plan' : 'Premium Abonnement'}
                </Text>
              </View>
            </View>

            <View className="items-end">
              <Text 
                style={{
                  color: colors.primary.violet,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                {currentPlan.price}
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 12,
                }}
              >
                {currentPlan.billing}
              </Text>
            </View>
          </View>

          {/* Plan Details */}
          {!isFreePlan && subscription.expiresAt && (
            <View className="space-y-2 mb-4">
              <View className="flex-row justify-between">
                <Text style={{ color: colors.glass.textSecondary, fontSize: 14 }}>
                  Gestartet am:
                </Text>
                <Text style={{ color: colors.glass.text, fontSize: 14 }}>
                  {formatDate(subscription.startedAt)}
                </Text>
              </View>
              
              <View className="flex-row justify-between">
                <Text style={{ color: colors.glass.textSecondary, fontSize: 14 }}>
                  Läuft ab am:
                </Text>
                <Text style={{ color: colors.glass.text, fontSize: 14 }}>
                  {formatDate(subscription.expiresAt)}
                </Text>
              </View>
            </View>
          )}

          {/* Session Usage */}
          <View 
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.05)',
              padding: 16,
              borderRadius: 12,
              marginBottom: 16,
            }}
          >
            <Text 
              style={{
                color: colors.glass.text,
                fontSize: 16,
                fontWeight: '600',
                marginBottom: 8,
              }}
            >
              Sessions diesen Monat
            </Text>
            
            {isFreePlan ? (
              <View>
                <View className="flex-row justify-between items-center mb-2">
                  <Text style={{ color: colors.glass.textSecondary, fontSize: 14 }}>
                    Verbraucht:
                  </Text>
                  <Text style={{ color: colors.glass.text, fontSize: 14 }}>
                    {2 - remainingSessions}/2
                  </Text>
                </View>
                
                <View 
                  style={{
                    height: 4,
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    borderRadius: 2,
                    marginTop: 8,
                    overflow: 'hidden',
                  }}
                >
                  <View 
                    style={{
                      height: '100%',
                      width: `${((2 - remainingSessions) / 2) * 100}%`,
                      backgroundColor: remainingSessions === 0 
                        ? colors.status.error 
                        : colors.status.success,
                      borderRadius: 2,
                    }}
                  />
                </View>
              </View>
            ) : (
              <View className="flex-row items-center">
                <Ionicons 
                  name="infinite" 
                  size={20} 
                  color={colors.primary.violet}
                  style={{ marginRight: 8 }}
                />
                <Text 
                  style={{
                    color: colors.primary.violet,
                    fontSize: 16,
                    fontWeight: '600',
                  }}
                >
                  Unbegrenzt
                </Text>
              </View>
            )}
          </View>

          {/* Action Buttons */}
          {isFreePlan ? (
            <GlassButton
              title="Zu Pro upgraden"
              icon="rocket"
              variant="primary"
              onPress={() => setShowPaymentModal(true)}
            />
          ) : (
            <View className="space-y-3">
              <GlassButton
                title="Plan ändern"
                icon="swap-horizontal"
                variant="secondary"
                onPress={() => setShowPaymentModal(true)}
              />
              <GlassButton
                title="Abonnement kündigen"
                icon="close-circle"
                variant="danger"
                onPress={handleCancelSubscription}
              />
            </View>
          )}
        </GlassCard>

        {/* Features Overview */}
        <GlassCard className="mb-6">
          <Text 
            style={{
              color: colors.glass.text,
              fontSize: 18,
              fontWeight: '600',
              marginBottom: 16,
            }}
          >
            Ihre Funktionen
          </Text>
          
          <View className="space-y-3">
            {currentPlan.features.map((feature, index) => (
              <View key={index} className="flex-row items-center">
                <Ionicons 
                  name="checkmark-circle" 
                  size={18} 
                  color={colors.status.success}
                  style={{ marginRight: 12 }}
                />
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 14,
                    flex: 1,
                  }}
                >
                  {feature}
                </Text>
              </View>
            ))}
          </View>
        </GlassCard>

        {/* Billing History */}
        {!isFreePlan && (
          <GlassCard>
            <Text 
              style={{
                color: colors.glass.text,
                fontSize: 18,
                fontWeight: '600',
                marginBottom: 16,
              }}
            >
              Rechnungsverlauf
            </Text>
            
            <View className="space-y-3">
              <View className="flex-row justify-between items-center py-3 border-b border-opacity-10" style={{ borderColor: colors.glass.border }}>
                <View>
                  <Text style={{ color: colors.glass.text, fontSize: 14, fontWeight: '500' }}>
                    {currentPlan.name}
                  </Text>
                  <Text style={{ color: colors.glass.textSecondary, fontSize: 12 }}>
                    {formatDate(subscription.startedAt)}
                  </Text>
                </View>
                <Text style={{ color: colors.primary.violet, fontSize: 14, fontWeight: '600' }}>
                  {currentPlan.price}
                </Text>
              </View>
            </View>
          </GlassCard>
        )}
      </ScrollView>

      {/* Payment Modal */}
      <PaymentModal
        visible={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onPlanSelected={(plan) => {
          console.log('Plan changed to:', plan);
        }}
      />
    </AppBackground>
  );
};