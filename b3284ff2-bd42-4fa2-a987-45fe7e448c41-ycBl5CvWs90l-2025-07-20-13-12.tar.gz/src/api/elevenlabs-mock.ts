// Mock ElevenLabs Implementation for Development
// This provides the same interface but with simulated responses

export interface ConversationConfig {
  agentId?: string;
  sessionId?: string;
  scenario?: string;
  mode?: 'practice' | 'coaching';
  voiceId?: string;
}

export interface ConversationMessage {
  id: string;
  timestamp: Date;
  type: 'user' | 'ai';
  text: string;
  audioUrl?: string;
  duration?: number;
}

export interface ElevenLabsError {
  message: string;
  code?: string;
}

export class ElevenLabsConversation {
  private sessionId: string;
  private messages: ConversationMessage[] = [];
  private isConnected: boolean = false;
  private conversationCount: number = 0;
  
  // Event callbacks
  private onMessageCallback?: (message: ConversationMessage) => void;
  private onErrorCallback?: (error: ElevenLabsError) => void;
  private onConnectCallback?: () => void;
  private onDisconnectCallback?: () => void;

  constructor(private config: ConversationConfig) {
    this.sessionId = config.sessionId || `session_${Date.now()}`;
  }

  // Event listeners
  onMessage(callback: (message: ConversationMessage) => void) {
    this.onMessageCallback = callback;
  }

  onError(callback: (error: ElevenLabsError) => void) {
    this.onErrorCallback = callback;
  }

  onConnect(callback: () => void) {
    this.onConnectCallback = callback;
  }

  onDisconnect(callback: () => void) {
    this.onDisconnectCallback = callback;
  }

  async startConversation(): Promise<void> {
    try {
      // Simulate connection delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      this.isConnected = true;
      this.onConnectCallback?.();
      
      console.log('Mock ElevenLabs conversation started:', this.config);
      
    } catch (error) {
      console.error('Failed to start mock conversation:', error);
      this.onErrorCallback?.({ 
        message: 'Failed to start conversation', 
        code: 'CONNECTION_ERROR' 
      });
      throw error;
    }
  }

  async sendAudioMessage(audioUri: string): Promise<ConversationMessage> {
    if (!this.isConnected) {
      throw new Error('Conversation not started');
    }

    // Create user message from audio
    const userMessage: ConversationMessage = {
      id: `msg_${Date.now()}_user`,
      timestamp: new Date(),
      type: 'user',
      text: 'Mock transcription: ' + this.generateMockUserInput(),
      duration: Math.random() * 5 + 2, // 2-7 seconds
    };

    this.messages.push(userMessage);
    this.onMessageCallback?.(userMessage);

    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 1000));

    // Generate AI response
    const aiMessage: ConversationMessage = {
      id: `msg_${Date.now()}_ai`,
      timestamp: new Date(),
      type: 'ai',
      text: this.generateMockAIResponse(userMessage.text),
      audioUrl: 'mock_audio_url', // In real app, this would be base64 audio
      duration: Math.random() * 6 + 3, // 3-9 seconds
    };

    this.messages.push(aiMessage);
    this.onMessageCallback?.(aiMessage);
    this.conversationCount++;

    return aiMessage;
  }

  private generateMockUserInput(): string {
    const inputs = [
      "Hallo, ich freue mich auf unser Gespräch heute.",
      "Können Sie mir mehr über die Position erzählen?",
      "Ich habe mehrjährige Erfahrung in diesem Bereich.",
      "Meine Stärken liegen in der Teamführung und Kommunikation.",
      "Ich möchte gerne über meine Gehaltsvorstellungen sprechen.",
      "Welche Herausforderungen gibt es in dieser Rolle?",
      "Ich bin sehr motiviert für diese Herausforderung.",
    ];
    return inputs[Math.floor(Math.random() * inputs.length)];
  }

  private generateMockAIResponse(userInput: string): string {
    const responses = this.getScenarioResponses();
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    
    // Add some context based on conversation count
    if (this.conversationCount > 5 && this.config.mode === 'coaching') {
      return randomResponse + " Das war ein sehr gutes Gespräch. Sollen wir das Feedback besprechen?";
    }
    
    return randomResponse;
  }

  private getScenarioResponses(): string[] {
    switch (this.config.scenario) {
      case 'job-interview-hr':
      case 'hr-interview':
        return [
          "Das ist sehr interessant. Können Sie mir ein konkretes Beispiel dafür geben?",
          "Verstehe ich Sie richtig, dass Sie bereits Führungserfahrung haben?",
          "Was motiviert Sie besonders an dieser Position?",
          "Wie gehen Sie mit Stress und Deadlines um?",
          "Erzählen Sie mir von einer Herausforderung, die Sie gemeistert haben.",
          "Welche Fragen haben Sie denn an uns als Unternehmen?",
          "Das klingt sehr vielversprechend. Wie sehen Sie Ihre berufliche Zukunft?",
        ];

      case 'salary-negotiation':
      case 'gehaltsverhandlung':
        return [
          "Auf welche Zahlen und Leistungen stützen Sie diese Forderung?",
          "Können Sie mir Ihre Erfolge der letzten Zeit genauer erläutern?",
          "Wie bewerten Sie Ihren Beitrag zum Unternehmenserfolg?",
          "Das ist eine substanzielle Erhöhung. Womit begründen Sie diese?",
          "Haben Sie Vergleichswerte aus der Branche recherchiert?",
          "Welche zusätzlichen Verantwortungen würden Sie übernehmen?",
        ];

      case 'startup-pitch':
      case 'investor-meeting':
        return [
          "Wie groß ist der Markt für Ihre Lösung tatsächlich?",
          "Was unterscheidet Sie von der Konkurrenz?",
          "Wie sehen Ihre Finanzkennzahlen aus?",
          "Welche Risiken sehen Sie für Ihr Geschäftsmodell?",
          "Wie erfahren ist Ihr Team in diesem Bereich?",
          "Wann erwarten Sie Break-even zu erreichen?",
          "Welche Meilensteine haben Sie bereits erreicht?",
        ];

      case 'networking-event':
      case 'networking':
        return [
          "Das ist sehr interessant! In welcher Branche sind Sie tätig?",
          "Kennen Sie schon andere Leute hier auf dem Event?",
          "Wie sind Sie denn zu diesem Bereich gekommen?",
          "Das klingt spannend. Können wir uns mal auf einen Kaffee treffen?",
          "Haben Sie schon von der neuen Initiative gehört?",
          "Ich kenne jemanden, der für Sie interessant sein könnte.",
          "Lassen Sie uns unsere Kontaktdaten austauschen.",
        ];

      default:
        return [
          "Das ist eine interessante Perspektive. Können Sie mir mehr darüber erzählen?",
          "Verstehe ich Sie richtig, dass Sie damit meinen...?",
          "Das ist ein wichtiger Punkt. Wie würden Sie das in der Praxis umsetzen?",
          "Sehr gut! Können Sie ein konkretes Beispiel dafür geben?",
          "Danke für Ihre Antwort. Was sind Ihrer Meinung nach die größten Herausforderungen dabei?",
          "Interessant! Wie gehen Sie mit Widerstand oder Kritik zu diesem Thema um?",
          "Das zeigt viel Erfahrung. Wie würden Sie das an Kollegen weitergeben?",
        ];
    }
  }

  getMessages(): ConversationMessage[] {
    return [...this.messages];
  }

  async endConversation(): Promise<void> {
    console.log('Ending mock conversation...');
    this.isConnected = false;
    this.onDisconnectCallback?.();
  }

  async generateFeedback(): Promise<string> {
    if (this.config.mode !== 'coaching') {
      return '';
    }

    // Simulate feedback generation delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    const feedbackTemplates = [
      `**Feedback zu Ihrer Session:**

**Stärken:**
- Klare und professionelle Kommunikation
- Gute Struktur in den Antworten
- Überzeugende Beispiele und Argumente
- Angemessene Körpersprache und Tonfall

**Verbesserungsmöglichkeiten:**
- Mehr konkrete Zahlen und Fakten einbauen
- Längere Pausen für Nachfragen lassen
- Noch selbstbewusster auftreten
- Mehr Rückfragen an den Gesprächspartner stellen

**Empfehlungen:**
- Üben Sie spezifische Antworten auf häufige Fragen
- Bereiten Sie mehr konkrete Beispiele vor
- Arbeiten Sie an Ihrer Körpersprache vor dem Spiegel
- Führen Sie weitere Practice-Sessions durch

**Bewertung: ${(Math.random() * 2 + 7).toFixed(1)}/10**`,

      `**Session-Auswertung:**

**Das haben Sie gut gemacht:**
- Professioneller Gesprächseinstieg
- Klare Kommunikation Ihrer Stärken
- Gute Reaktion auf schwierige Fragen
- Angemessenes Tempo im Gespräch

**Hier können Sie sich verbessern:**
- Mehr Selbstvertrauen bei der Selbstpräsentation
- Konkretere Beispiele aus der Praxis
- Aktiveres Nachfragen zum Unternehmen
- Körpersprache noch bewusster einsetzen

**Nächste Schritte:**
- Bereiten Sie 3-5 STAR-Beispiele vor
- Üben Sie vor Freunden oder Familie
- Informieren Sie sich intensiver über das Unternehmen
- Wiederholen Sie schwierige Gesprächssituationen

**Ihre Note: ${(Math.random() * 2.5 + 6.5).toFixed(1)}/10**`
    ];

    return feedbackTemplates[Math.floor(Math.random() * feedbackTemplates.length)];
  }

  isConnectionActive(): boolean {
    return this.isConnected;
  }
}

// Helper function to create conversation instance
export const createConversation = (config: ConversationConfig): ElevenLabsConversation => {
  return new ElevenLabsConversation(config);
};