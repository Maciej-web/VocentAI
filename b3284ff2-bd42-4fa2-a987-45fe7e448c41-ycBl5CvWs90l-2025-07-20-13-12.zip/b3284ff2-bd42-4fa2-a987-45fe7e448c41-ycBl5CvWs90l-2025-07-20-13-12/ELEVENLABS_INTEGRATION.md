# ElevenLabs Conversational AI Integration

## Übersicht

Die Vocent AI App nutzt die ElevenLabs Conversational AI API für echte Voice-to-Voice Gespräche. Die Integration ermöglicht:

- **Real-time WebSocket-Verbindungen** für sofortige Sprachantworten  
- **Automatic Speech Recognition (ASR)** für Benutzer-Eingaben
- **Text-to-Speech (TTS)** für KI-Antworten
- **Intelligente Gesprächsführung** mit anpassbaren Prompts
- **Strukturiertes Feedback** für Coaching-Sessions

## API-Setup

### Voraussetzungen
- ElevenLabs API-Key in `.env` als `EXPO_PUBLIC_VIBECODE_ELEVENLABS_API_KEY`
- WebSocket-Unterstützung für Real-time-Kommunikation
- Audio-Aufnahme-Berechtigung für Mikrofon-Zugriff

### Agent-Konfiguration
```typescript
const agentConfig = {
  name: `Vocent AI ${mode} - ${scenario}`,
  prompt: getSystemPrompt(), // Szenario-spezifische Prompts
  voice: {
    voice_id: "21m00Tcm4TlvDq8ikWAM", // Professionelle Stimme
    stability: 0.5,
    similarity_boost: 0.75,
    style: 0.0,
    use_speaker_boost: true
  },
  conversation_config: {
    turn_detection: {
      type: "server_vad", // Voice Activity Detection
      threshold: 0.5,
      prefix_padding_ms: 300,
      silence_duration_ms: 800
    }
  }
}
```

## Verwendung

### 1. Conversation starten
```typescript
const conversation = createConversation({
  mode: 'practice', // oder 'coaching'
  scenario: 'job-interview-hr',
  voiceId: 'voice_id_here'
});

await conversation.startConversation();
```

### 2. Event Listeners
```typescript
conversation.onConnect(() => {
  console.log('Verbunden!');
});

conversation.onMessage((message) => {
  // Neue Nachricht verarbeiten
});

conversation.onError((error) => {
  console.error('Fehler:', error);
});
```

### 3. Audio streamen
```typescript
// Audio-Chunks an ElevenLabs senden
await conversation.sendAudioChunk(audioBuffer);
```

## Komponenten

### VoiceChat
- Hauptkomponente für Voice-Interaktion
- Integrierte Aufnahme mit visuellen Effekten
- Automatische Audio-Streaming
- Connection-Status-Management

### AudioPlayer  
- Wiedergabe von KI-Audio-Antworten
- Unterstützt Base64 und URL-Audio
- Progress-Anzeige und Playback-Controls

### ConnectionStatus
- Visuelle Anzeige der Verbindung
- Retry-Funktionalität bei Fehlern
- Status-Indikatoren (verbunden/getrennt/fehler)

## Szenario-spezifische Prompts

### Job Interview
```
Sie führen ein HR-Vorstellungsgespräch. Sie sind ein erfahrener HR-Manager und bewerten den Kandidaten fair aber kritisch. Stellen Sie typische HR-Fragen zu Motivation, Teamwork, Stärken/Schwächen etc.
```

### Gehaltsverhandlung
```
Sie sind ein Vorgesetzter in einer Gehaltsverhandlung. Seien Sie professionell aber verhandlungsbereit. Fragen Sie nach Begründungen und Leistungen.
```

### Startup Pitch
```
Sie sind ein potentieller Investor. Stellen Sie kritische Fragen zum Geschäftsmodell, Markt, Finanzen und Team.
```

## Fehlerbehandlung

### Häufige Probleme
1. **Keine API-Key** → Überprüfen Sie die `.env` Datei
2. **WebSocket-Fehler** → Netzwerkverbindung prüfen
3. **Mikrofon-Berechtigung** → Berechtigungen in App-Einstellungen
4. **Audio-Format** → 16kHz, Mono, WAV empfohlen

### Error Codes
- `CONNECTION_ERROR`: WebSocket-Verbindung fehlgeschlagen
- `WEBSOCKET_ERROR`: WebSocket-Kommunikationsfehler  
- `AUDIO_ERROR`: Audio-Verarbeitungsfehler
- `API_ERROR`: ElevenLabs API-Fehler

## Performance-Optimierung

### Audio-Streaming
- Audio wird in 100ms-Chunks gestreamt
- Pufferung minimiert Latenz
- Automatische Qualitätsanpassung

### Ressourcen-Management
- WebSocket-Verbindungen werden ordnungsgemäß geschlossen
- Audio-Ressourcen werden nach Gebrauch freigegeben
- Memory-Leaks durch korrekte Cleanup-Funktionen vermieden

## Testing

### Mock-Modus
Für Entwicklung ohne API-Key ist ein Mock-Modus implementiert:
- Simulierte Antworten mit zeitlicher Verzögerung
- Lokale Audio-Verarbeitung ohne Cloud-Calls
- Vollständige UI-Funktionalität für Testing

### Debug-Informationen
```typescript
console.log('Conversation ID:', conversation.getConversationId());
console.log('Connection Status:', conversation.isConnectionActive());
console.log('Message History:', conversation.getMessages());
```

## Deployment

### Production Setup
1. Gültiger ElevenLabs API-Key erforderlich
2. WebSocket-Proxies für Firewalls konfigurieren
3. Audio-Berechtigungen in App-Store-Beschreibung erwähnen
4. HTTPS für sichere WebSocket-Connections

### Rate Limits
- ElevenLabs API hat Usage-Limits basierend auf Plan
- Implementieren Sie Retry-Logic mit exponential backoff
- Überwachen Sie API-Usage über ElevenLabs Dashboard