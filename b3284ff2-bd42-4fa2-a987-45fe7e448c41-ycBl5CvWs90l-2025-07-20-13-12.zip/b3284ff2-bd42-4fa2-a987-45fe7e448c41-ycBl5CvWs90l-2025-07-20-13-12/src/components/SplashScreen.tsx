import React, { useEffect, useRef } from 'react';
import { View, Text, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../utils/colors';
import { VocentLogo } from './VocentLogo';

export const SplashScreen: React.FC = () => {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const glowAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const animation = Animated.sequence([
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 50,
          friction: 7,
          useNativeDriver: true,
        }),
      ]),
      Animated.timing(glowAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: false,
      }),
    ]);

    animation.start();

    return () => {
      animation.stop();
    };
  }, []);

  return (
    <View style={{ flex: 1 }}>
      <LinearGradient
        colors={[
          colors.background.gradient.start,
          colors.background.gradient.middle,
          colors.background.gradient.end,
        ]}
        style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}
      >
        <Animated.View
          style={{
            opacity: fadeAnim,
            transform: [{ scale: scaleAnim }],
            alignItems: 'center',
          }}
        >
          {/* Logo */}
          <Animated.View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 32,
              shadowColor: colors.primary.violet,
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: glowAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0.4, 0.9],
              }),
              shadowRadius: glowAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [12, 32],
              }),
              elevation: 16,
            }}
          >
            <VocentLogo size={120} />
          </Animated.View>

          {/* Title */}
          <Text 
            style={{
              color: colors.glass.text,
              fontSize: 36,
              fontWeight: 'bold',
              marginBottom: 8,
              textAlign: 'center',
            }}
          >
            Vocent AI
          </Text>
          
          <Text 
            style={{
              color: colors.glass.textSecondary,
              fontSize: 16,
              textAlign: 'center',
              lineHeight: 22,
            }}
          >
            Business Gespräche{'\n'}mit KI trainieren
          </Text>
        </Animated.View>
      </LinearGradient>
    </View>
  );
};