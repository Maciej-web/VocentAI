import React, { useState, useRef, useEffect } from 'react';
import { View, Pressable, Animated, Text } from 'react-native';
import { Audio } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../utils/colors';
import { ElevenLabsConversation, ConversationMessage } from '../api/elevenlabs';

interface VoiceChatProps {
  conversation: ElevenLabsConversation | null;
  onMessage?: (message: ConversationMessage) => void;
  onError?: (error: string) => void;
  disabled?: boolean;
  size?: 'small' | 'medium' | 'large';
}

export const VoiceChat: React.FC<VoiceChatProps> = ({
  conversation,
  onMessage,
  onError,
  disabled = false,
  size = 'large',
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  
  const recording = useRef<Audio.Recording | null>(null);
  const recordingInterval = useRef<NodeJS.Timeout | null>(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const glowAnim = useRef(new Animated.Value(0)).current;

  const getSizeStyles = () => {
    switch (size) {
      case 'small':
        return { size: 60, iconSize: 24 };
      case 'medium':
        return { size: 80, iconSize: 32 };
      case 'large':
        return { size: 100, iconSize: 40 };
      default:
        return { size: 100, iconSize: 40 };
    }
  };

  const sizeStyles = getSizeStyles();

  useEffect(() => {
    if (conversation) {
      setupConversationListeners();
    }
    return () => {
      cleanupRecording();
    };
  }, [conversation]);

  const setupConversationListeners = () => {
    if (!conversation) return;

    conversation.onConnect(() => {
      setConnectionStatus('connected');
    });

    conversation.onDisconnect(() => {
      setConnectionStatus('disconnected');
      setIsRecording(false);
      setIsProcessing(false);
      stopPulseAnimation();
    });

    conversation.onMessage((message) => {
      setIsProcessing(false);
      onMessage?.(message);
    });

    conversation.onError((error) => {
      setIsProcessing(false);
      setIsRecording(false);
      stopPulseAnimation();
      onError?.(error.message);
    });
  };

  const startPulseAnimation = () => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
      ])
    );

    const glow = Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: false,
        }),
        Animated.timing(glowAnim, {
          toValue: 0.3,
          duration: 1000,
          useNativeDriver: false,
        }),
      ])
    );

    pulse.start();
    glow.start();
  };

  const stopPulseAnimation = () => {
    pulseAnim.stopAnimation(() => {
      Animated.timing(pulseAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();
    });

    glowAnim.stopAnimation(() => {
      Animated.timing(glowAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: false,
      }).start();
    });
  };

  const startRecording = async () => {
    if (!conversation || !conversation.isConnectionActive()) {
      onError?.('Keine Verbindung zur KI');
      return;
    }

    try {
      setIsProcessing(true);
      
      // Request permissions
      const permissionResponse = await Audio.requestPermissionsAsync();
      if (permissionResponse.status !== 'granted') {
        onError?.('Mikrofonberechtigung erforderlich');
        setIsProcessing(false);
        return;
      }

      // Configure audio mode for high quality recording
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
        staysActiveInBackground: false,
        shouldDuckAndroid: false,
        playThroughEarpieceAndroid: false,
      });

      // Start recording with settings optimized for ElevenLabs
      const recordingOptions = {
        android: {
          extension: '.wav',
          outputFormat: Audio.AndroidOutputFormat.DEFAULT,
          audioEncoder: Audio.AndroidAudioEncoder.DEFAULT,
          sampleRate: 16000,
          numberOfChannels: 1,
          bitRate: 128000,
        },
        ios: {
          extension: '.wav',
          outputFormat: Audio.IOSOutputFormat.LINEARPCM,
          audioQuality: Audio.IOSAudioQuality.HIGH,
          sampleRate: 16000,
          numberOfChannels: 1,
          bitRate: 128000,
          linearPCMBitDepth: 16,
          linearPCMIsBigEndian: false,
          linearPCMIsFloat: false,
        },
        web: {
          mimeType: 'audio/wav',
          bitsPerSecond: 128000,
        },
      };

      const { recording: newRecording } = await Audio.Recording.createAsync(recordingOptions);
      recording.current = newRecording;
      
      setIsRecording(true);
      setIsProcessing(false);
      startPulseAnimation();

      // Start streaming audio chunks to ElevenLabs
      startAudioStreaming();

    } catch (error) {
      console.error('Failed to start recording:', error);
      onError?.('Aufnahme konnte nicht gestartet werden');
      setIsProcessing(false);
    }
  };

  const startAudioStreaming = () => {
    // Stream audio in chunks every 100ms
    recordingInterval.current = setInterval(async () => {
      if (!recording.current || !conversation) return;

      try {
        // Get current recording status and audio data
        const status = await recording.current.getStatusAsync();
        if (status.isRecording && status.durationMillis > 0) {
          // In a real implementation, you would capture audio chunks here
          // and send them to ElevenLabs via conversation.sendAudioChunk()
          // This is a simplified version
        }
      } catch (error) {
        console.error('Error streaming audio:', error);
      }
    }, 100);
  };

  const stopRecording = async () => {
    if (!recording.current) return;

    try {
      setIsProcessing(true);
      stopPulseAnimation();

      // Clear streaming interval
      if (recordingInterval.current) {
        clearInterval(recordingInterval.current);
        recordingInterval.current = null;
      }

      await recording.current.stopAndUnloadAsync();
      const uri = recording.current.getURI();
      
      if (uri && conversation) {
        // Convert audio file to ArrayBuffer and send to ElevenLabs
        const response = await fetch(uri);
        const audioBuffer = await response.arrayBuffer();
        await conversation.sendAudioChunk(audioBuffer);
      }

      recording.current = null;
      setIsRecording(false);

    } catch (error) {
      console.error('Failed to stop recording:', error);
      onError?.('Aufnahme konnte nicht beendet werden');
      setIsRecording(false);
      setIsProcessing(false);
    }
  };

  const cleanupRecording = async () => {
    if (recordingInterval.current) {
      clearInterval(recordingInterval.current);
      recordingInterval.current = null;
    }

    if (recording.current) {
      try {
        await recording.current.stopAndUnloadAsync();
      } catch (error) {
        console.error('Error cleaning up recording:', error);
      }
      recording.current = null;
    }
    
    stopPulseAnimation();
  };

  const handlePress = () => {
    if (disabled || isProcessing || connectionStatus !== 'connected') return;
    
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const getButtonColor = () => {
    if (disabled || connectionStatus !== 'connected') return colors.glass.textSecondary;
    if (isRecording) return colors.status.error;
    if (isProcessing) return colors.status.warning;
    return colors.primary.violet;
  };

  const getIconName = (): keyof typeof Ionicons.glyphMap => {
    if (connectionStatus === 'connecting' || isProcessing) return 'ellipse';
    if (isRecording) return 'stop';
    return 'mic';
  };

  const getStatusText = () => {
    if (connectionStatus === 'connecting') return 'Verbinde...';
    if (connectionStatus === 'disconnected') return 'Nicht verbunden';
    if (isProcessing) return 'Verarbeite...';
    if (isRecording) return 'Sprechen Sie jetzt';
    return 'Tippen zum Sprechen';
  };

  return (
    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
      {/* Connection Status */}
      <View className="flex-row items-center mb-4">
        <View 
          style={{
            width: 8,
            height: 8,
            borderRadius: 4,
            backgroundColor: connectionStatus === 'connected' 
              ? colors.status.success 
              : connectionStatus === 'connecting'
              ? colors.status.warning
              : colors.status.error,
            marginRight: 8,
          }}
        />
        <Text 
          style={{
            color: colors.glass.textSecondary,
            fontSize: 12,
          }}
        >
          {connectionStatus === 'connected' ? 'Verbunden' : 
           connectionStatus === 'connecting' ? 'Verbinde...' : 'Getrennt'}
        </Text>
      </View>

      {/* Glow effect while recording */}
      {isRecording && (
        <Animated.View
          style={{
            position: 'absolute',
            width: sizeStyles.size + 40,
            height: sizeStyles.size + 40,
            borderRadius: (sizeStyles.size + 40) / 2,
            backgroundColor: colors.status.error,
            opacity: glowAnim.interpolate({
              inputRange: [0, 1],
              outputRange: [0.1, 0.3],
            }),
          }}
        />
      )}

      <Animated.View
        style={{
          transform: [{ scale: pulseAnim }],
        }}
      >
        <Pressable
          onPress={handlePress}
          style={({ pressed }) => ({
            width: sizeStyles.size,
            height: sizeStyles.size,
            borderRadius: sizeStyles.size / 2,
            backgroundColor: `${getButtonColor()}20`,
            borderWidth: 3,
            borderColor: getButtonColor(),
            alignItems: 'center',
            justifyContent: 'center',
            shadowColor: getButtonColor(),
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: pressed ? 0.4 : 0.2,
            shadowRadius: pressed ? 16 : 8,
            elevation: pressed ? 16 : 8,
            transform: [{ scale: pressed ? 0.95 : 1 }],
            opacity: disabled || connectionStatus !== 'connected' ? 0.5 : 1,
          })}
        >
          <Ionicons
            name={getIconName()}
            size={sizeStyles.iconSize}
            color={getButtonColor()}
          />
        </Pressable>
      </Animated.View>

      {/* Status Text */}
      <Text 
        style={{
          color: colors.glass.textSecondary,
          fontSize: 14,
          textAlign: 'center',
          marginTop: 16,
          lineHeight: 20,
        }}
      >
        {getStatusText()}
      </Text>
    </View>
  );
};