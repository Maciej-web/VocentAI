import React from 'react';
import { View, ViewProps } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../utils/colors';
import { cn } from '../utils/cn';

interface AppBackgroundProps extends ViewProps {
  children: React.ReactNode;
  variant?: 'default' | 'glow';
  className?: string;
}

export const AppBackground: React.FC<AppBackgroundProps> = ({
  children,
  variant = 'default',
  className,
  style,
  ...props
}) => {
  if (variant === 'glow') {
    return (
      <View 
        style={[{ flex: 1 }, style]} 
        className={cn('', className)}
        {...props}
      >
        <LinearGradient
          colors={[
            colors.background.gradient.start,
            colors.background.gradient.middle,
            colors.background.gradient.end,
          ]}
          locations={[0, 0.5, 1]}
          style={{ flex: 1 }}
        >
          {/* Subtle glow effects */}
          <View
            style={{
              position: 'absolute',
              top: 100,
              left: -50,
              width: 200,
              height: 200,
              borderRadius: 100,
              backgroundColor: colors.primary.violet,
              opacity: 0.05,
              blur: 100,
            }}
          />
          <View
            style={{
              position: 'absolute',
              bottom: 200,
              right: -30,
              width: 150,
              height: 150,
              borderRadius: 75,
              backgroundColor: colors.primary.turquoise,
              opacity: 0.03,
              blur: 80,
            }}
          />
          {children}
        </LinearGradient>
      </View>
    );
  }

  return (
    <View 
      style={[
        { 
          flex: 1, 
          backgroundColor: colors.background.primary 
        }, 
        style
      ]} 
      className={cn('', className)}
      {...props}
    >
      {children}
    </View>
  );
};