import React, { useState, useRef, useEffect } from 'react';
import { View, Pressable, Text } from 'react-native';
import { Audio } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../utils/colors';

interface AudioPlayerProps {
  audioUrl?: string;
  audioBase64?: string;
  duration?: number;
  onPlaybackComplete?: () => void;
  size?: 'small' | 'medium';
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
  audioUrl,
  audioBase64,
  duration,
  onPlaybackComplete,
  size = 'small',
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [playbackStatus, setPlaybackStatus] = useState<any>(null);
  const sound = useRef<Audio.Sound | null>(null);

  const getSizeStyles = () => {
    switch (size) {
      case 'small':
        return { buttonSize: 32, iconSize: 16 };
      case 'medium':
        return { buttonSize: 40, iconSize: 20 };
      default:
        return { buttonSize: 32, iconSize: 16 };
    }
  };

  const sizeStyles = getSizeStyles();

  useEffect(() => {
    return () => {
      // Cleanup on unmount
      if (sound.current) {
        sound.current.unloadAsync();
      }
    };
  }, []);

  const createSoundFromBase64 = async (base64Data: string): Promise<Audio.Sound> => {
    // Convert base64 to blob and create object URL
    const byteString = atob(base64Data);
    const byteArray = new Uint8Array(byteString.length);
    
    for (let i = 0; i < byteString.length; i++) {
      byteArray[i] = byteString.charCodeAt(i);
    }
    
    const blob = new Blob([byteArray], { type: 'audio/wav' });
    const url = URL.createObjectURL(blob);
    
    const { sound: newSound } = await Audio.Sound.createAsync(
      { uri: url },
      { shouldPlay: false }
    );
    
    return newSound;
  };

  const playAudio = async () => {
    if (!audioUrl && !audioBase64) return;

    try {
      setIsLoading(true);

      // Stop current sound if playing
      if (sound.current && isPlaying) {
        await sound.current.stopAsync();
        setIsPlaying(false);
        setIsLoading(false);
        return;
      }

      // Configure audio mode
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true,
        shouldDuckAndroid: true,
        playThroughEarpieceAndroid: false,
      });

      // Create sound object
      if (audioBase64) {
        // Handle base64 audio data from ElevenLabs
        sound.current = await createSoundFromBase64(audioBase64);
      } else if (audioUrl) {
        // Handle regular audio URL
        const { sound: newSound } = await Audio.Sound.createAsync(
          { uri: audioUrl },
          { shouldPlay: false }
        );
        sound.current = newSound;
      }

      if (!sound.current) {
        throw new Error('Could not create sound');
      }

      // Set up playback status listener
      sound.current.setOnPlaybackStatusUpdate((status) => {
        setPlaybackStatus(status);
        
        if (status.isLoaded) {
          if (status.didJustFinish) {
            setIsPlaying(false);
            onPlaybackComplete?.();
          }
        }
      });

      // Start playback
      await sound.current.playAsync();
      setIsPlaying(true);
      setIsLoading(false);

    } catch (error) {
      console.error('Error playing audio:', error);
      setIsLoading(false);
      setIsPlaying(false);
    }
  };

  const stopAudio = async () => {
    if (sound.current) {
      try {
        await sound.current.stopAsync();
        setIsPlaying(false);
      } catch (error) {
        console.error('Error stopping audio:', error);
      }
    }
  };

  const formatDuration = (milliseconds: number) => {
    const totalSeconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getCurrentPosition = () => {
    if (playbackStatus?.isLoaded && playbackStatus.positionMillis) {
      return formatDuration(playbackStatus.positionMillis);
    }
    return '0:00';
  };

  const getTotalDuration = () => {
    if (duration) {
      return formatDuration(duration * 1000);
    }
    if (playbackStatus?.isLoaded && playbackStatus.durationMillis) {
      return formatDuration(playbackStatus.durationMillis);
    }
    return '0:00';
  };

  if (!audioUrl && !audioBase64) {
    return null;
  }

  return (
    <View className="flex-row items-center space-x-3">
      <Pressable
        onPress={isPlaying ? stopAudio : playAudio}
        style={({ pressed }) => ({
          width: sizeStyles.buttonSize,
          height: sizeStyles.buttonSize,
          borderRadius: sizeStyles.buttonSize / 2,
          backgroundColor: 'rgba(59, 130, 246, 0.2)',
          borderWidth: 1,
          borderColor: colors.primary.blue,
          alignItems: 'center',
          justifyContent: 'center',
          transform: [{ scale: pressed ? 0.95 : 1 }],
          opacity: isLoading ? 0.6 : 1,
        })}
        disabled={isLoading}
      >
        <Ionicons
          name={
            isLoading 
              ? 'ellipse' 
              : isPlaying 
              ? 'pause' 
              : 'play'
          }
          size={sizeStyles.iconSize}
          color={colors.primary.blue}
        />
      </Pressable>

      {/* Duration Display */}
      <View className="flex-row items-center">
        <Text 
          style={{
            color: colors.glass.textSecondary,
            fontSize: 12,
            fontFamily: 'monospace',
          }}
        >
          {getCurrentPosition()}
        </Text>
        <Text 
          style={{
            color: colors.glass.textSecondary,
            fontSize: 12,
            marginHorizontal: 4,
          }}
        >
          /
        </Text>
        <Text 
          style={{
            color: colors.glass.textSecondary,
            fontSize: 12,
            fontFamily: 'monospace',
          }}
        >
          {getTotalDuration()}
        </Text>
      </View>

      {/* Progress Bar (optional) */}
      {isPlaying && playbackStatus?.isLoaded && (
        <View 
          style={{
            flex: 1,
            height: 2,
            backgroundColor: 'rgba(255, 255, 255, 0.2)',
            borderRadius: 1,
            overflow: 'hidden',
          }}
        >
          <View 
            style={{
              height: '100%',
              width: `${(playbackStatus.positionMillis / playbackStatus.durationMillis) * 100}%`,
              backgroundColor: colors.primary.blue,
            }}
          />
        </View>
      )}
    </View>
  );
};