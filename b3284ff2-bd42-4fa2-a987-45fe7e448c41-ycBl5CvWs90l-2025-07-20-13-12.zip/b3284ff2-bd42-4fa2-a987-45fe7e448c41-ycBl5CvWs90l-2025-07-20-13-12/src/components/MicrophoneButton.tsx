import React, { useState, useRef } from 'react';
import { View, Pressable, Animated } from 'react-native';
import { Audio } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../utils/colors';

interface MicrophoneButtonProps {
  onRecordingStart?: () => void;
  onRecordingStop?: (audioUri: string) => void;
  onRecordingError?: (error: string) => void;
  disabled?: boolean;
  size?: 'small' | 'medium' | 'large';
}

export const MicrophoneButton: React.FC<MicrophoneButtonProps> = ({
  onRecordingStart,
  onRecordingStop,
  onRecordingError,
  disabled = false,
  size = 'large',
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const recording = useRef<Audio.Recording | null>(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const glowAnim = useRef(new Animated.Value(0)).current;

  const getSizeStyles = () => {
    switch (size) {
      case 'small':
        return { size: 60, iconSize: 24 };
      case 'medium':
        return { size: 80, iconSize: 32 };
      case 'large':
        return { size: 100, iconSize: 40 };
      default:
        return { size: 100, iconSize: 40 };
    }
  };

  const sizeStyles = getSizeStyles();

  const startPulseAnimation = () => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
      ])
    );

    const glow = Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: false,
        }),
        Animated.timing(glowAnim, {
          toValue: 0.3,
          duration: 1000,
          useNativeDriver: false,
        }),
      ])
    );

    pulse.start();
    glow.start();
  };

  const stopPulseAnimation = () => {
    pulseAnim.stopAnimation(() => {
      Animated.timing(pulseAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();
    });

    glowAnim.stopAnimation(() => {
      Animated.timing(glowAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: false,
      }).start();
    });
  };

  const startRecording = async () => {
    try {
      setIsLoading(true);
      
      // Request permissions
      const permissionResponse = await Audio.requestPermissionsAsync();
      if (permissionResponse.status !== 'granted') {
        onRecordingError?.('Mikrofonberechtigung erforderlich');
        setIsLoading(false);
        return;
      }

      // Configure audio mode
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

      // Start recording
      const { recording: newRecording } = await Audio.Recording.createAsync(
        Audio.RecordingOptionsPresets.HIGH_QUALITY
      );

      recording.current = newRecording;
      setIsRecording(true);
      setIsLoading(false);
      startPulseAnimation();
      onRecordingStart?.();

    } catch (error) {
      console.error('Failed to start recording:', error);
      onRecordingError?.('Aufnahme konnte nicht gestartet werden');
      setIsLoading(false);
    }
  };

  const stopRecording = async () => {
    if (!recording.current) return;

    try {
      setIsLoading(true);
      stopPulseAnimation();

      await recording.current.stopAndUnloadAsync();
      const uri = recording.current.getURI();
      
      if (uri) {
        onRecordingStop?.(uri);
      }

      recording.current = null;
      setIsRecording(false);
      setIsLoading(false);

    } catch (error) {
      console.error('Failed to stop recording:', error);
      onRecordingError?.('Aufnahme konnte nicht beendet werden');
      setIsRecording(false);
      setIsLoading(false);
    }
  };

  const handlePress = () => {
    if (disabled || isLoading) return;
    
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const getButtonColor = () => {
    if (disabled) return colors.glass.textSecondary;
    if (isRecording) return colors.status.error;
    return colors.primary.violet;
  };

  const getIconName = (): keyof typeof Ionicons.glyphMap => {
    if (isLoading) return 'ellipse';
    if (isRecording) return 'stop';
    return 'mic';
  };

  return (
    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
      {/* Glow effect while recording */}
      {isRecording && (
        <Animated.View
          style={{
            position: 'absolute',
            width: sizeStyles.size + 40,
            height: sizeStyles.size + 40,
            borderRadius: (sizeStyles.size + 40) / 2,
            backgroundColor: colors.status.error,
            opacity: glowAnim.interpolate({
              inputRange: [0, 1],
              outputRange: [0.1, 0.3],
            }),
          }}
        />
      )}

      <Animated.View
        style={{
          transform: [{ scale: pulseAnim }],
        }}
      >
        <Pressable
          onPress={handlePress}
          style={({ pressed }) => ({
            width: sizeStyles.size,
            height: sizeStyles.size,
            borderRadius: sizeStyles.size / 2,
            backgroundColor: `${getButtonColor()}20`,
            borderWidth: 3,
            borderColor: getButtonColor(),
            alignItems: 'center',
            justifyContent: 'center',
            shadowColor: getButtonColor(),
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: pressed ? 0.4 : 0.2,
            shadowRadius: pressed ? 16 : 8,
            elevation: pressed ? 16 : 8,
            transform: [{ scale: pressed ? 0.95 : 1 }],
            opacity: disabled ? 0.5 : 1,
          })}
        >
          <Ionicons
            name={getIconName()}
            size={sizeStyles.iconSize}
            color={getButtonColor()}
          />
        </Pressable>
      </Animated.View>
    </View>
  );
};