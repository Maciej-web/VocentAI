import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';

import { AppBackground } from '../components/AppBackground';
import { GlassCard } from '../components/GlassCard';
import { GlassButton } from '../components/GlassButton';
import { MicrophoneButton } from '../components/MicrophoneButton';
import { colors } from '../utils/colors';
import { createConversation, ConversationMessage, ElevenLabsConversation } from '../api/elevenlabs-mock';

export const CoachingScreen = () => {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const [conversation, setConversation] = useState<ElevenLabsConversation | null>(null);
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [sessionProgress, setSessionProgress] = useState(0);
  const [currentScenario] = useState('Vorstellungsgespräch - HR Interview');
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [sessionComplete, setSessionComplete] = useState(false);

  useEffect(() => {
    initializeConversation();
    return () => {
      conversation?.endConversation();
    };
  }, []);

  const initializeConversation = async () => {
    try {
      const newConversation = createConversation({
        mode: 'coaching',
        scenario: 'job-interview-hr',
      });
      
      newConversation.onConnect(() => {
        setIsConnected(true);
      });

      newConversation.onMessage((message) => {
        setMessages(prev => {
          const exists = prev.some(m => m.id === message.id);
          if (exists) {
            return prev.map(m => m.id === message.id ? message : m);
          } else {
            return [...prev, message];
          }
        });
      });

      newConversation.onError((error) => {
        console.error('Conversation error:', error);
        setIsConnected(false);
      });
      
      await newConversation.startConversation();
      setConversation(newConversation);

      // Add structured coaching welcome message
      const welcomeMessage: ConversationMessage = {
        id: 'welcome',
        timestamp: new Date(),
        type: 'ai',
        text: 'Willkommen zum Coaching-Modus! Ich führe Sie durch ein strukturiertes Vorstellungsgespräch. Stellen Sie sich vor, Sie bewerben sich als Marketing Manager. Sind Sie bereit? Beginnen Sie mit einer kurzen Vorstellung.',
      };
      setMessages([welcomeMessage]);

    } catch (error) {
      console.error('Failed to initialize conversation:', error);
      setIsConnected(false);
    }
  };

  const handleRecordingStart = () => {
    console.log('Recording started...');
  };

  const handleRecordingStop = async (audioUri: string) => {
    if (!conversation) return;

    try {
      setIsProcessing(true);
      
      await conversation.sendAudioMessage(audioUri);
      
      // Update session progress (mock calculation)
      const allMessages = conversation.getMessages();
      const newProgress = Math.min((allMessages.length / 10) * 100, 100);
      setSessionProgress(newProgress);

      // Check if session should end (after ~5 exchanges)
      if (allMessages.length >= 10 && !sessionComplete) {
        setTimeout(() => {
          completeSession();
        }, 2000);
      }

    } catch (error) {
      console.error('Failed to process audio:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRecordingError = (error: string) => {
    console.error('Recording error:', error);
  };

  const completeSession = async () => {
    if (!conversation) return;

    try {
      setSessionComplete(true);
      const generatedFeedback = await conversation.generateFeedback();
      setFeedback(generatedFeedback);
      setShowFeedback(true);
    } catch (error) {
      console.error('Failed to generate feedback:', error);
    }
  };

  const endSession = async () => {
    if (conversation) {
      await conversation.endConversation();
    }
    navigation.goBack();
  };

  return (
    <AppBackground variant="glow">
      <KeyboardAvoidingView 
        style={{ flex: 1 }} 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {/* Header */}
        <View 
          style={{
            paddingTop: insets.top + 10,
            paddingHorizontal: 20,
            paddingBottom: 20,
          }}
        >
          <View className="flex-row items-center justify-between mb-4">
            <GlassButton
              icon="chevron-back"
              size="small"
              variant="secondary"
              onPress={() => navigation.goBack()}
            />
            
            <View className="flex-1 mx-4">
              <Text 
                style={{
                  color: colors.glass.text,
                  fontSize: 20,
                  fontWeight: '600',
                  textAlign: 'center',
                }}
              >
                Coaching Mode
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 14,
                  textAlign: 'center',
                }}
              >
                {currentScenario}
              </Text>
            </View>

            <GlassButton
              icon="close"
              size="small"
              variant="danger"
              onPress={endSession}
            />
          </View>

          {/* Progress Bar */}
          <GlassCard>
            <View className="flex-row items-center justify-between mb-2">
              <Text 
                style={{
                  color: colors.glass.text,
                  fontSize: 14,
                  fontWeight: '500',
                }}
              >
                Session Fortschritt
              </Text>
              <Text 
                style={{
                  color: colors.primary.violet,
                  fontSize: 14,
                  fontWeight: '600',
                }}
              >
                {Math.round(sessionProgress)}%
              </Text>
            </View>
            
            <View 
              style={{
                height: 6,
                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                borderRadius: 3,
                overflow: 'hidden',
              }}
            >
              <View 
                style={{
                  height: '100%',
                  width: `${sessionProgress}%`,
                  backgroundColor: colors.primary.violet,
                  borderRadius: 3,
                }}
              />
            </View>
          </GlassCard>

          {/* Connection Status */}
          <View className="flex-row items-center justify-center mt-4">
            <View 
              style={{
                width: 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: isConnected ? colors.status.success : colors.status.error,
                marginRight: 8,
              }}
            />
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 12,
              }}
            >
              {isConnected ? 'Coaching aktiv' : 'Verbinde...'}
            </Text>
          </View>
        </View>

        {/* Conversation Messages */}
        <ScrollView 
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingHorizontal: 20,
            paddingBottom: 20,
          }}
          showsVerticalScrollIndicator={false}
        >
          <View className="space-y-4">
            {messages.map((message) => (
              <View
                key={message.id}
                className={`flex-row ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <View
                  style={{
                    maxWidth: '80%',
                    backgroundColor: message.type === 'ai' 
                      ? colors.glass.background 
                      : 'rgba(59, 130, 246, 0.2)',
                    borderWidth: 1,
                    borderColor: message.type === 'ai' 
                      ? colors.glass.border 
                      : colors.primary.blue,
                    borderRadius: 16,
                    padding: 16,
                  }}
                >
                  <View className="flex-row items-center mb-2">
                    <Ionicons
                      name={message.type === 'ai' ? 'school' : 'person'}
                      size={16}
                      color={message.type === 'ai' ? colors.primary.blue : colors.primary.turquoise}
                    />
                    <Text 
                      style={{
                        color: colors.glass.textSecondary,
                        fontSize: 12,
                        marginLeft: 8,
                      }}
                    >
                      {message.type === 'ai' ? 'HR Manager' : 'Sie'}
                    </Text>
                  </View>
                  
                  <Text 
                    style={{
                      color: colors.glass.text,
                      fontSize: 16,
                      lineHeight: 22,
                    }}
                  >
                    {message.text}
                  </Text>

                  {message.duration && (
                    <Text 
                      style={{
                        color: colors.glass.textSecondary,
                        fontSize: 12,
                        marginTop: 8,
                        textAlign: 'right',
                      }}
                    >
                      {message.duration.toFixed(1)}s
                    </Text>
                  )}
                </View>
              </View>
            ))}

            {isProcessing && (
              <View className="flex-row justify-start">
                <GlassCard>
                  <View className="flex-row items-center">
                    <Ionicons
                      name="ellipse"
                      size={16}
                      color={colors.primary.blue}
                    />
                    <Text 
                      style={{
                        color: colors.glass.textSecondary,
                        fontSize: 14,
                        marginLeft: 8,
                      }}
                    >
                      HR Manager überlegt...
                    </Text>
                  </View>
                </GlassCard>
              </View>
            )}
          </View>
        </ScrollView>

        {/* Microphone Controls */}
        {!sessionComplete && (
          <View 
            style={{
              paddingHorizontal: 20,
              paddingBottom: insets.bottom + 100,
              paddingTop: 20,
              alignItems: 'center',
            }}
          >
            <MicrophoneButton
              onRecordingStart={handleRecordingStart}
              onRecordingStop={handleRecordingStop}
              onRecordingError={handleRecordingError}
              disabled={!isConnected || isProcessing}
              size="large"
            />
            
            <Text 
              style={{
                color: colors.glass.textSecondary,
                fontSize: 14,
                textAlign: 'center',
                marginTop: 16,
                lineHeight: 20,
              }}
            >
              {isProcessing 
                ? 'Analysiere Ihre Antwort...'
                : 'Antworten Sie dem HR Manager'
              }
            </Text>
          </View>
        )}

        {/* Feedback Modal */}
        <Modal
          visible={showFeedback}
          animationType="slide"
          presentationStyle="pageSheet"
        >
          <AppBackground>
            <View 
              style={{
                paddingTop: insets.top + 20,
                paddingHorizontal: 20,
                paddingBottom: insets.bottom + 20,
                flex: 1,
              }}
            >
              <View className="flex-row items-center justify-between mb-6">
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 24,
                    fontWeight: 'bold',
                  }}
                >
                  Session Feedback
                </Text>
                <GlassButton
                  icon="close"
                  size="small"
                  onPress={() => {
                    setShowFeedback(false);
                    endSession();
                  }}
                />
              </View>

              <ScrollView showsVerticalScrollIndicator={false}>
                <GlassCard>
                  <Text 
                    style={{
                      color: colors.glass.text,
                      fontSize: 16,
                      lineHeight: 24,
                    }}
                  >
                    {feedback}
                  </Text>
                </GlassCard>

                <View className="mt-6 space-y-4">
                  <GlassButton
                    title="Neue Session starten"
                    icon="refresh"
                    variant="primary"
                    onPress={() => {
                      setShowFeedback(false);
                      // Reset and start new session
                      setSessionComplete(false);
                      setSessionProgress(0);
                      setMessages([]);
                      initializeConversation();
                    }}
                  />
                  
                  <GlassButton
                    title="Zum Hauptmenü"
                    icon="home"
                    variant="secondary"
                    onPress={() => {
                      setShowFeedback(false);
                      endSession();
                    }}
                  />
                </View>
              </ScrollView>
            </View>
          </AppBackground>
        </Modal>
      </KeyboardAvoidingView>
    </AppBackground>
  );
};