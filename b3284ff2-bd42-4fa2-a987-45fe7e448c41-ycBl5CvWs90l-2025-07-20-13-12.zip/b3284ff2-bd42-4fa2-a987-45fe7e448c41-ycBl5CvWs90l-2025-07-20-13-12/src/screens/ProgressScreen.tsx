import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

import { AppBackground } from '../components/AppBackground';
import { GlassCard } from '../components/GlassCard';
import { GlassButton } from '../components/GlassButton';
import { colors } from '../utils/colors';

// Types for session history
interface SessionHistory {
  id: string;
  date: Date;
  type: 'practice' | 'coaching';
  scenario: string;
  duration: number;
  score?: number;
  transcript: string;
  feedback?: string;
  isBookmarked: boolean;
}

const progressData = {
  totalSessions: 24,
  totalMinutes: 156,
  averageScore: 7.8,
  streak: 5,
  skillProgress: [
    { name: 'Kommunikation', current: 8.2, target: 9.0, color: colors.primary.violet },
    { name: 'Überzeugungskraft', current: 7.5, target: 8.5, color: colors.primary.blue },
    { name: 'Struktur', current: 6.8, target: 8.0, color: colors.primary.turquoise },
    { name: 'Selbstvertrauen', current: 7.9, target: 9.0, color: colors.primary.purple },
  ],
  weeklyProgress: [
    { day: 'Mo', sessions: 2, score: 7.5 },
    { day: 'Di', sessions: 1, score: 8.0 },
    { day: 'Mi', sessions: 3, score: 7.2 },
    { day: 'Do', sessions: 0, score: 0 },
    { day: 'Fr', sessions: 2, score: 8.5 },
    { day: 'Sa', sessions: 1, score: 7.8 },
    { day: 'So', sessions: 1, score: 8.2 },
  ],
  achievements: [
    { 
      id: 'first-session', 
      title: 'Erste Schritte', 
      description: 'Erste Session abgeschlossen',
      unlocked: true,
      icon: 'star' as keyof typeof Ionicons.glyphMap,
      color: colors.status.success,
    },
    { 
      id: 'week-streak', 
      title: 'Wöchentlicher Streak', 
      description: '7 Tage in Folge geübt',
      unlocked: true,
      icon: 'flame' as keyof typeof Ionicons.glyphMap,
      color: colors.status.warning,
    },
    { 
      id: 'expert-level', 
      title: 'Experten-Level', 
      description: 'Durchschnittsscore von 8.5+',
      unlocked: false,
      icon: 'trophy' as keyof typeof Ionicons.glyphMap,
      color: colors.primary.violet,
    },
    { 
      id: 'master-speaker', 
      title: 'Meister-Redner', 
      description: '50 Sessions abgeschlossen',
      unlocked: false,
      icon: 'ribbon' as keyof typeof Ionicons.glyphMap,
      color: colors.primary.blue,
    },
  ]
};

const mockHistory: SessionHistory[] = [
  {
    id: '1',
    date: new Date(Date.now() - 24 * 60 * 60 * 1000), // Yesterday
    type: 'coaching',
    scenario: 'HR Interview - Marketing Manager',
    duration: 12.5,
    score: 8.2,
    transcript: 'User: Guten Tag, ich freue mich sehr auf unser Gespräch.\nAI: Herzlich willkommen! Erzählen Sie mir doch etwas über sich...',
    feedback: 'Sehr gute Einleitung und professionelle Ausstrahlung. Arbeiten Sie an konkreteren Beispielen.',
    isBookmarked: true,
  },
  {
    id: '2',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    type: 'practice',
    scenario: 'Freies Networking Gespräch',
    duration: 8.3,
    transcript: 'User: Hallo, ich bin neu hier. Darf ich mich vorstellen?\nAI: Natürlich! Schön, Sie kennenzulernen...',
    isBookmarked: false,
  },
  {
    id: '3',
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    type: 'coaching',
    scenario: 'Gehaltsverhandlung',
    duration: 15.2,
    score: 7.5,
    transcript: 'User: Ich möchte gerne über meine Gehaltsvorstellungen sprechen.\nAI: Das ist ein wichtiges Thema. Wie haben Sie sich auf diese Verhandlung vorbereitet?',
    feedback: 'Gute Vorbereitung, aber mehr Selbstvertrauen bei der Argumentation wäre hilfreich.',
    isBookmarked: false,
  },
  {
    id: '4',
    date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
    type: 'practice',
    scenario: 'Startup Pitch',
    duration: 6.8,
    transcript: 'User: Unsere Lösung revolutioniert die Art, wie Menschen...\nAI: Das klingt interessant. Können Sie mir das Problem genauer erklären?',
    isBookmarked: true,
  },
];

export const ProgressScreen = () => {
  const insets = useSafeAreaInsets();
  const [activeTab, setActiveTab] = useState<'stats' | 'history'>('stats');
  const [selectedSession, setSelectedSession] = useState<SessionHistory | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [historyFilter, setHistoryFilter] = useState<'all' | 'practice' | 'coaching'>('all');

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) return 'Heute';
    if (diffInDays === 1) return 'Gestern';
    if (diffInDays < 7) return `vor ${diffInDays} Tagen`;
    
    return date.toLocaleDateString('de-DE');
  };

  const formatDuration = (minutes: number) => {
    const mins = Math.floor(minutes);
    const secs = Math.floor((minutes - mins) * 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const filteredHistory = mockHistory.filter(session => {
    if (historyFilter === 'all') return true;
    return session.type === historyFilter;
  });

  const toggleBookmark = (sessionId: string) => {
    console.log('Toggle bookmark for session:', sessionId);
  };

  const openSessionDetails = (session: SessionHistory) => {
    setSelectedSession(session);
    setShowDetails(true);
  };

  const SkillProgressBar = ({ skill }: { skill: typeof progressData.skillProgress[0] }) => {
    const progress = (skill.current / 10) * 100;
    const targetProgress = (skill.target / 10) * 100;

    return (
      <View className="mb-4">
        <View className="flex-row justify-between items-center mb-2">
          <Text 
            style={{
              color: colors.glass.text,
              fontSize: 16,
              fontWeight: '500',
            }}
          >
            {skill.name}
          </Text>
          <Text 
            style={{
              color: skill.color,
              fontSize: 16,
              fontWeight: '600',
            }}
          >
            {skill.current.toFixed(1)}/10
          </Text>
        </View>
        
        <View 
          style={{
            height: 8,
            backgroundColor: 'rgba(255, 255, 255, 0.1)',
            borderRadius: 4,
            overflow: 'hidden',
          }}
        >
          {/* Target line */}
          <View 
            style={{
              position: 'absolute',
              left: `${targetProgress}%`,
              width: 2,
              height: '100%',
              backgroundColor: colors.glass.text,
              opacity: 0.5,
            }}
          />
          
          {/* Progress bar */}
          <LinearGradient
            colors={[skill.color, `${skill.color}80`]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={{
              height: '100%',
              width: `${progress}%`,
              borderRadius: 4,
            }}
          />
        </View>
        
        <Text 
          style={{
            color: colors.glass.textSecondary,
            fontSize: 12,
            marginTop: 4,
          }}
        >
          Ziel: {skill.target.toFixed(1)}
        </Text>
      </View>
    );
  };

  const StatsTab = () => (
    <>
      {/* Quick Stats */}
      <View className="flex-row flex-wrap justify-between mb-6">
        <View className="w-[48%] mb-4">
          <GlassCard>
            <View className="items-center">
              <Ionicons 
                name="trophy" 
                size={32} 
                color={colors.primary.violet}
                style={{ marginBottom: 8 }}
              />
              <Text 
                style={{
                  color: colors.primary.violet,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                {progressData.totalSessions}
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 14,
                  textAlign: 'center',
                }}
              >
                Sessions
              </Text>
            </View>
          </GlassCard>
        </View>

        <View className="w-[48%] mb-4">
          <GlassCard>
            <View className="items-center">
              <Ionicons 
                name="time" 
                size={32} 
                color={colors.primary.blue}
                style={{ marginBottom: 8 }}
              />
              <Text 
                style={{
                  color: colors.primary.blue,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                {Math.floor(progressData.totalMinutes / 60)}h {progressData.totalMinutes % 60}m
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 14,
                  textAlign: 'center',
                }}
              >
                Übungszeit
              </Text>
            </View>
          </GlassCard>
        </View>

        <View className="w-[48%] mb-4">
          <GlassCard>
            <View className="items-center">
              <Ionicons 
                name="trending-up" 
                size={32} 
                color={colors.primary.turquoise}
                style={{ marginBottom: 8 }}
              />
              <Text 
                style={{
                  color: colors.primary.turquoise,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                {progressData.averageScore}
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 14,
                  textAlign: 'center',
                }}
              >
                Ø Score
              </Text>
            </View>
          </GlassCard>
        </View>

        <View className="w-[48%] mb-4">
          <GlassCard>
            <View className="items-center">
              <Ionicons 
                name="flame" 
                size={32} 
                color={colors.status.warning}
                style={{ marginBottom: 8 }}
              />
              <Text 
                style={{
                  color: colors.status.warning,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                {progressData.streak}
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 14,
                  textAlign: 'center',
                }}
              >
                Tage Streak
              </Text>
            </View>
          </GlassCard>
        </View>
      </View>

      {/* Skill Progress */}
      <GlassCard className="mb-6">
        <Text 
          style={{
            color: colors.glass.text,
            fontSize: 20,
            fontWeight: '600',
            marginBottom: 20,
          }}
        >
          Skill-Entwicklung
        </Text>
        
        {progressData.skillProgress.map((skill, index) => (
          <SkillProgressBar key={index} skill={skill} />
        ))}
      </GlassCard>

      {/* Weekly Activity */}
      <GlassCard className="mb-6">
        <Text 
          style={{
            color: colors.glass.text,
            fontSize: 20,
            fontWeight: '600',
            marginBottom: 20,
          }}
        >
          Wochenaktivität
        </Text>
        
        <View className="flex-row justify-between">
          {progressData.weeklyProgress.map((day, index) => (
            <View key={index} className="items-center">
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 12,
                  marginBottom: 8,
                }}
              >
                {day.day}
              </Text>
              
              <View 
                style={{
                  width: 8,
                  height: Math.max(day.sessions * 15, 8),
                  backgroundColor: day.sessions > 0 ? colors.primary.violet : colors.glass.border,
                  borderRadius: 4,
                  marginBottom: 8,
                }}
              />
              
              <Text 
                style={{
                  color: day.sessions > 0 ? colors.glass.text : colors.glass.textSecondary,
                  fontSize: 12,
                  fontWeight: '600',
                }}
              >
                {day.sessions}
              </Text>
            </View>
          ))}
        </View>
      </GlassCard>

      {/* Achievements */}
      <GlassCard>
        <Text 
          style={{
            color: colors.glass.text,
            fontSize: 20,
            fontWeight: '600',
            marginBottom: 20,
          }}
        >
          Errungenschaften
        </Text>
        
        <View className="space-y-4">
          {progressData.achievements.map((achievement) => (
            <View 
              key={achievement.id}
              className="flex-row items-center"
              style={{
                opacity: achievement.unlocked ? 1 : 0.5,
              }}
            >
              <View 
                style={{
                  width: 50,
                  height: 50,
                  borderRadius: 25,
                  backgroundColor: `${achievement.color}20`,
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: 16,
                }}
              >
                <Ionicons 
                  name={achievement.icon} 
                  size={24} 
                  color={achievement.color}
                />
              </View>
              
              <View className="flex-1">
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 16,
                    fontWeight: '600',
                    marginBottom: 2,
                  }}
                >
                  {achievement.title}
                </Text>
                <Text 
                  style={{
                    color: colors.glass.textSecondary,
                    fontSize: 14,
                  }}
                >
                  {achievement.description}
                </Text>
              </View>
              
              {achievement.unlocked && (
                <Ionicons 
                  name="checkmark-circle" 
                  size={24} 
                  color={colors.status.success}
                />
              )}
            </View>
          ))}
        </View>
      </GlassCard>
    </>
  );

  const HistoryTab = () => (
    <>
      {/* Filter Buttons */}
      <View className="flex-row justify-center mb-6 space-x-2">
        {[
          { key: 'all', label: 'Alle' },
          { key: 'practice', label: 'Practice' },
          { key: 'coaching', label: 'Coaching' },
        ].map((filterOption) => (
          <GlassButton
            key={filterOption.key}
            title={filterOption.label}
            size="small"
            variant={historyFilter === filterOption.key ? 'primary' : 'secondary'}
            onPress={() => setHistoryFilter(filterOption.key as any)}
          />
        ))}
      </View>

      {/* Session List */}
      <View className="space-y-4">
        {filteredHistory.map((session) => (
          <Pressable
            key={session.id}
            onPress={() => openSessionDetails(session)}
          >
            <GlassCard>
              <View className="flex-row items-start justify-between">
                <View className="flex-1">
                  {/* Session Header */}
                  <View className="flex-row items-center mb-2">
                    <View 
                      style={{
                        width: 32,
                        height: 32,
                        borderRadius: 16,
                        backgroundColor: session.type === 'coaching' 
                          ? 'rgba(59, 130, 246, 0.2)' 
                          : 'rgba(139, 92, 246, 0.2)',
                        alignItems: 'center',
                        justifyContent: 'center',
                        marginRight: 12,
                      }}
                    >
                      <Ionicons
                        name={session.type === 'coaching' ? 'school' : 'chatbubbles'}
                        size={16}
                        color={session.type === 'coaching' ? colors.primary.blue : colors.primary.violet}
                      />
                    </View>
                    
                    <View className="flex-1">
                      <Text 
                        style={{
                          color: colors.glass.text,
                          fontSize: 16,
                          fontWeight: '600',
                        }}
                      >
                        {session.scenario}
                      </Text>
                      <Text 
                        style={{
                          color: colors.glass.textSecondary,
                          fontSize: 12,
                          textTransform: 'capitalize',
                        }}
                      >
                        {session.type} • {formatDate(session.date)}
                      </Text>
                    </View>
                  </View>

                  {/* Session Stats */}
                  <View className="flex-row items-center space-x-4">
                    <View className="flex-row items-center">
                      <Ionicons 
                        name="time" 
                        size={14} 
                        color={colors.glass.textSecondary}
                        style={{ marginRight: 4 }}
                      />
                      <Text 
                        style={{
                          color: colors.glass.textSecondary,
                          fontSize: 14,
                        }}
                      >
                        {formatDuration(session.duration)}
                      </Text>
                    </View>

                    {session.score && (
                      <View className="flex-row items-center">
                        <Ionicons 
                          name="star" 
                          size={14} 
                          color={colors.primary.violet}
                          style={{ marginRight: 4 }}
                        />
                        <Text 
                          style={{
                            color: colors.primary.violet,
                            fontSize: 14,
                            fontWeight: '600',
                          }}
                        >
                          {session.score}/10
                        </Text>
                      </View>
                    )}
                  </View>
                </View>

                {/* Actions */}
                <View className="flex-row items-center space-x-2 ml-4">
                  <Pressable
                    onPress={(e) => {
                      e.stopPropagation();
                      toggleBookmark(session.id);
                    }}
                    style={{
                      padding: 8,
                    }}
                  >
                    <Ionicons
                      name={session.isBookmarked ? 'bookmark' : 'bookmark-outline'}
                      size={20}
                      color={session.isBookmarked ? colors.primary.turquoise : colors.glass.textSecondary}
                    />
                  </Pressable>
                  
                  <Ionicons
                    name="chevron-forward"
                    size={16}
                    color={colors.glass.textSecondary}
                  />
                </View>
              </View>
            </GlassCard>
          </Pressable>
        ))}

        {filteredHistory.length === 0 && (
          <GlassCard>
            <View className="items-center py-8">
              <Ionicons 
                name="document-text-outline" 
                size={48} 
                color={colors.glass.textSecondary}
                style={{ marginBottom: 16 }}
              />
              <Text 
                style={{
                  color: colors.glass.text,
                  fontSize: 18,
                  fontWeight: '600',
                  marginBottom: 8,
                  textAlign: 'center',
                }}
              >
                Keine Sessions gefunden
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 14,
                  textAlign: 'center',
                }}
              >
                Starte deine erste Session im Speak-Bereich
              </Text>
            </View>
          </GlassCard>
        )}
      </View>
    </>
  );

  return (
    <AppBackground>
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ 
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="mb-8">
          <Text 
            style={{ 
              color: colors.glass.text,
              fontSize: 28,
              fontWeight: 'bold',
              textAlign: 'center',
              marginBottom: 8,
            }}
          >
            Progress & Verlauf
          </Text>
          <Text 
            style={{ 
              color: colors.glass.textSecondary,
              fontSize: 16,
              textAlign: 'center',
            }}
          >
            Deine Entwicklung und Sessions
          </Text>
        </View>

        {/* Tab Switcher */}
        <View className="flex-row mb-6">
          <GlassButton
            title="Statistiken"
            icon="trending-up"
            variant={activeTab === 'stats' ? 'primary' : 'secondary'}
            className="flex-1 mr-2"
            onPress={() => setActiveTab('stats')}
          />
          <GlassButton
            title="Verlauf"
            icon="time"
            variant={activeTab === 'history' ? 'primary' : 'secondary'}
            className="flex-1 ml-2"
            onPress={() => setActiveTab('history')}
          />
        </View>

        {/* Tab Content */}
        {activeTab === 'stats' ? <StatsTab /> : <HistoryTab />}
      </ScrollView>

      {/* Session Details Modal */}
      <Modal
        visible={showDetails && selectedSession !== null}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        {selectedSession && (
          <AppBackground>
            <View 
              style={{
                paddingTop: insets.top + 20,
                paddingHorizontal: 20,
                paddingBottom: insets.bottom + 20,
                flex: 1,
              }}
            >
              {/* Modal Header */}
              <View className="flex-row items-center justify-between mb-6">
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 24,
                    fontWeight: 'bold',
                    flex: 1,
                  }}
                >
                  Session Details
                </Text>
                <GlassButton
                  icon="close"
                  size="small"
                  onPress={() => setShowDetails(false)}
                />
              </View>

              <ScrollView showsVerticalScrollIndicator={false}>
                {/* Session Info */}
                <GlassCard className="mb-6">
                  <Text 
                    style={{
                      color: colors.glass.text,
                      fontSize: 20,
                      fontWeight: '600',
                      marginBottom: 16,
                    }}
                  >
                    {selectedSession.scenario}
                  </Text>
                  
                  <View className="space-y-3">
                    <View className="flex-row justify-between">
                      <Text style={{ color: colors.glass.textSecondary, fontSize: 14 }}>
                        Typ:
                      </Text>
                      <Text style={{ color: colors.glass.text, fontSize: 14, textTransform: 'capitalize' }}>
                        {selectedSession.type}
                      </Text>
                    </View>
                    
                    <View className="flex-row justify-between">
                      <Text style={{ color: colors.glass.textSecondary, fontSize: 14 }}>
                        Datum:
                      </Text>
                      <Text style={{ color: colors.glass.text, fontSize: 14 }}>
                        {formatDate(selectedSession.date)}
                      </Text>
                    </View>
                    
                    <View className="flex-row justify-between">
                      <Text style={{ color: colors.glass.textSecondary, fontSize: 14 }}>
                        Dauer:
                      </Text>
                      <Text style={{ color: colors.glass.text, fontSize: 14 }}>
                        {formatDuration(selectedSession.duration)}
                      </Text>
                    </View>
                    
                    {selectedSession.score && (
                      <View className="flex-row justify-between">
                        <Text style={{ color: colors.glass.textSecondary, fontSize: 14 }}>
                          Bewertung:
                        </Text>
                        <Text style={{ color: colors.primary.violet, fontSize: 14, fontWeight: '600' }}>
                          {selectedSession.score}/10
                        </Text>
                      </View>
                    )}
                  </View>
                </GlassCard>

                {/* Transcript */}
                <GlassCard className="mb-6">
                  <Text 
                    style={{
                      color: colors.glass.text,
                      fontSize: 18,
                      fontWeight: '600',
                      marginBottom: 16,
                    }}
                  >
                    Gesprächsverlauf
                  </Text>
                  <Text 
                    style={{
                      color: colors.glass.text,
                      fontSize: 14,
                      lineHeight: 20,
                    }}
                  >
                    {selectedSession.transcript}
                  </Text>
                </GlassCard>

                {/* Feedback */}
                {selectedSession.feedback && (
                  <GlassCard className="mb-6">
                    <Text 
                      style={{
                        color: colors.glass.text,
                        fontSize: 18,
                        fontWeight: '600',
                        marginBottom: 16,
                      }}
                    >
                      KI-Feedback
                    </Text>
                    <Text 
                      style={{
                        color: colors.glass.text,
                        fontSize: 14,
                        lineHeight: 20,
                      }}
                    >
                      {selectedSession.feedback}
                    </Text>
                  </GlassCard>
                )}

                {/* Actions */}
                <View className="space-y-4">
                  <GlassButton
                    title="Session wiederholen"
                    icon="refresh"
                    variant="primary"
                    onPress={() => {
                      setShowDetails(false);
                      // TODO: Start new session with same scenario
                    }}
                  />
                  
                  <GlassButton
                    title={selectedSession.isBookmarked ? 'Aus Favoriten entfernen' : 'Zu Favoriten hinzufügen'}
                    icon={selectedSession.isBookmarked ? 'bookmark' : 'bookmark-outline'}
                    variant="secondary"
                    onPress={() => {
                      toggleBookmark(selectedSession.id);
                      setShowDetails(false);
                    }}
                  />
                </View>
              </ScrollView>
            </View>
          </AppBackground>
        )}
      </Modal>
    </AppBackground>
  );
};