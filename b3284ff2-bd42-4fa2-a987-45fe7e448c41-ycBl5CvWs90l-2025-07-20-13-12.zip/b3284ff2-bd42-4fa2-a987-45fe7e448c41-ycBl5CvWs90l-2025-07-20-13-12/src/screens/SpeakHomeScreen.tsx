import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';

import { AppBackground } from '../components/AppBackground';
import { GlassCard } from '../components/GlassCard';
import { GlassButton } from '../components/GlassButton';
import { SubscriptionStatus } from '../components/SubscriptionStatus';
import { PaymentModal } from '../components/PaymentModal';
import { VocentLogo } from '../components/VocentLogo';
import { colors } from '../utils/colors';
import { useSubscriptionStore } from '../state/subscriptionStore';

export const SpeakHomeScreen = () => {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { 
    initializeSubscription, 
    canUseSession, 
    useSession, 
    showPaywall, 
    setShowPaywall 
  } = useSubscriptionStore();
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  useEffect(() => {
    initializeSubscription();
  }, []);

  useEffect(() => {
    if (showPaywall) {
      setShowPaymentModal(true);
      setShowPaywall(false);
    }
  }, [showPaywall]);

  const handleStartSession = (type: 'practice' | 'coaching') => {
    if (!canUseSession()) {
      setShowPaymentModal(true);
      return;
    }

    if (useSession()) {
      if (type === 'practice') {
        navigation.navigate('Practice' as never);
      } else {
        navigation.navigate('Coaching' as never);
      }
    }
  };

  return (
    <AppBackground variant="glow">
      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ 
          paddingTop: insets.top + 20,
          paddingBottom: insets.bottom + 100,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="mb-8">
          {/* Logo and Title */}
          <View className="items-center">
            <VocentLogo size={80} style={{ marginBottom: 16 }} />
            <Text 
              style={{ 
                color: colors.glass.text,
                fontSize: 32,
                fontWeight: 'bold',
                textAlign: 'center',
                marginBottom: 8,
              }}
            >
              Vocent AI
            </Text>
            <Text 
              style={{ 
                color: colors.glass.textSecondary,
                fontSize: 16,
                textAlign: 'center',
                lineHeight: 24,
              }}
            >
              Trainiere realistische Business-Gespräche{'\n'}mit KI-Sprachsimulation
            </Text>
          </View>
        </View>

        {/* Quick Stats */}
        <GlassCard className="mb-6">
          <Text 
            style={{
              color: colors.glass.text,
              fontSize: 18,
              fontWeight: '600',
              marginBottom: 16,
              textAlign: 'center',
            }}
          >
            Deine Fortschritte
          </Text>
          
          <View className="flex-row justify-between">
            <View className="items-center flex-1">
              <Text 
                style={{
                  color: colors.primary.violet,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                12
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 12,
                  textAlign: 'center',
                }}
              >
                Sessions
              </Text>
            </View>
            
            <View className="items-center flex-1">
              <Text 
                style={{
                  color: colors.primary.turquoise,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                5
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 12,
                  textAlign: 'center',
                }}
              >
                Szenarien
              </Text>
            </View>
            
            <View className="items-center flex-1">
              <Text 
                style={{
                  color: colors.primary.blue,
                  fontSize: 24,
                  fontWeight: 'bold',
                }}
              >
                2h 34m
              </Text>
              <Text 
                style={{
                  color: colors.glass.textSecondary,
                  fontSize: 12,
                  textAlign: 'center',
                }}
              >
                Übungszeit
              </Text>
            </View>
          </View>
        </GlassCard>

        {/* Main Action Cards */}
        <View className="space-y-4 mb-8">
          {/* Practice Card */}
          <GlassCard>
            <View className="flex-row items-center mb-4">
              <View 
                style={{
                  width: 50,
                  height: 50,
                  borderRadius: 25,
                  backgroundColor: 'rgba(139, 92, 246, 0.2)',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: 16,
                }}
              >
                <Ionicons 
                  name="chatbubbles" 
                  size={24} 
                  color={colors.primary.violet}
                />
              </View>
              <View className="flex-1">
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 20,
                    fontWeight: '600',
                    marginBottom: 4,
                  }}
                >
                  Practice Mode
                </Text>
                <Text 
                  style={{
                    color: colors.glass.textSecondary,
                    fontSize: 14,
                    lineHeight: 20,
                  }}
                >
                  Freies Üben mit KI in lockerer Atmosphäre
                </Text>
              </View>
            </View>
            
            <GlassButton
              title="Jetzt üben"
              icon="play"
              variant="primary"
              onPress={() => handleStartSession('practice')}
            />
          </GlassCard>

          {/* Coaching Card */}
          <GlassCard>
            <View className="flex-row items-center mb-4">
              <View 
                style={{
                  width: 50,
                  height: 50,
                  borderRadius: 25,
                  backgroundColor: 'rgba(59, 130, 246, 0.2)',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: 16,
                }}
              >
                <Ionicons 
                  name="school" 
                  size={24} 
                  color={colors.primary.blue}
                />
              </View>
              <View className="flex-1">
                <Text 
                  style={{
                    color: colors.glass.text,
                    fontSize: 20,
                    fontWeight: '600',
                    marginBottom: 4,
                  }}
                >
                  Coaching Mode
                </Text>
                <Text 
                  style={{
                    color: colors.glass.textSecondary,
                    fontSize: 14,
                    lineHeight: 20,
                  }}
                >
                  Geführte Sessions mit detailliertem Feedback
                </Text>
              </View>
            </View>
            
            <GlassButton
              title="Coaching starten"
              icon="trophy"
              variant="secondary"
              onPress={() => handleStartSession('coaching')}
            />
          </GlassCard>
        </View>

        {/* Subscription Status */}
        <View className="mb-6">
          <SubscriptionStatus onUpgradePress={() => setShowPaymentModal(true)} />
        </View>
      </ScrollView>

      {/* Payment Modal */}
      <PaymentModal
        visible={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onPlanSelected={(plan) => {
          console.log('Plan selected:', plan);
          // Session can now be started
        }}
      />
    </AppBackground>
  );
};