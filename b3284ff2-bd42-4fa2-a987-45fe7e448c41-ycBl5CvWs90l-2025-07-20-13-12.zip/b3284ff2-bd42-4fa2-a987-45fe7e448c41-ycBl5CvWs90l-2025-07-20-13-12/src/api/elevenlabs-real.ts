// Real ElevenLabs Conversational AI Integration
const ELEVENLABS_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_ELEVENLABS_API_KEY;
const ELEVENLABS_BASE_URL = 'https://api.elevenlabs.io/v1';

export interface ConversationConfig {
  agentId?: string;
  sessionId?: string;
  scenario?: string;
  mode?: 'practice' | 'coaching';
  voiceId?: string;
}

export interface ConversationMessage {
  id: string;
  timestamp: Date;
  type: 'user' | 'ai';
  text: string;
  audioUrl?: string;
  duration?: number;
}

export class ElevenLabsConversation {
  private sessionId: string;
  private messages: ConversationMessage[] = [];
  private isConnected: boolean = false;
  private websocket: WebSocket | null = null;
  private voiceId: string;

  constructor(private config: ConversationConfig) {
    this.sessionId = config.sessionId || `session_${Date.now()}`;
    // Rachel voice ID (default ElevenLabs voice)
    this.voiceId = config.voiceId || '21m00Tcm4TlvDq8ikWAM';
  }

  async startConversation(): Promise<void> {
    if (!ELEVENLABS_API_KEY) {
      throw new Error('ElevenLabs API key not found');
    }

    try {
      // Initialize conversational AI session
      const response = await fetch(`${ELEVENLABS_BASE_URL}/convai/conversations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'xi-api-key': ELEVENLABS_API_KEY,
        },
        body: JSON.stringify({
          agent_id: this.config.agentId || 'default',
          voice_id: this.voiceId,
          conversation_config: {
            mode: this.config.mode || 'practice',
            scenario: this.config.scenario || 'business-conversation',
          }
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to start conversation: ${response.statusText}`);
      }

      const data = await response.json();
      this.isConnected = true;
      console.log('ElevenLabs conversation started:', data);

    } catch (error) {
      console.error('Failed to start ElevenLabs conversation:', error);
      throw error;
    }
  }

  async sendAudioMessage(audioBlob: Blob): Promise<ConversationMessage> {
    if (!this.isConnected) {
      throw new Error('Conversation not started');
    }

    if (!ELEVENLABS_API_KEY) {
      throw new Error('ElevenLabs API key not found');
    }

    try {
      // Convert audio blob to base64 or FormData
      const formData = new FormData();
      formData.append('audio', audioBlob, 'audio.wav');
      formData.append('voice_id', this.voiceId);

      // Step 1: Speech-to-Text
      const transcriptionResponse = await fetch(`${ELEVENLABS_BASE_URL}/speech-to-text`, {
        method: 'POST',
        headers: {
          'xi-api-key': ELEVENLABS_API_KEY,
        },
        body: formData,
      });

      if (!transcriptionResponse.ok) {
        throw new Error('Speech-to-text failed');
      }

      const transcriptionData = await transcriptionResponse.json();
      const userText = transcriptionData.text;

      // Create user message
      const userMessage: ConversationMessage = {
        id: `msg_${Date.now()}_user`,
        timestamp: new Date(),
        type: 'user',
        text: userText,
        duration: audioBlob.size / 16000, // Rough estimate
      };

      this.messages.push(userMessage);

      // Step 2: Generate AI response using conversational AI
      const conversationResponse = await fetch(`${ELEVENLABS_BASE_URL}/convai/conversations/${this.sessionId}/message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'xi-api-key': ELEVENLABS_API_KEY,
        },
        body: JSON.stringify({
          text: userText,
          voice_id: this.voiceId,
        }),
      });

      if (!conversationResponse.ok) {
        throw new Error('Conversation response failed');
      }

      const responseData = await conversationResponse.json();
      
      // Create AI message
      const aiMessage: ConversationMessage = {
        id: `msg_${Date.now()}_ai`,
        timestamp: new Date(),
        type: 'ai',
        text: responseData.text,
        audioUrl: responseData.audio_url,
        duration: responseData.duration,
      };

      this.messages.push(aiMessage);
      return aiMessage;

    } catch (error) {
      console.error('Failed to process audio message:', error);
      throw error;
    }
  }

  getMessages(): ConversationMessage[] {
    return [...this.messages];
  }

  async endConversation(): Promise<void> {
    if (this.websocket) {
      this.websocket.close();
      this.websocket = null;
    }
    this.isConnected = false;
    console.log('ElevenLabs conversation ended');
  }

  async generateFeedback(): Promise<string> {
    if (this.config.mode !== 'coaching') {
      return '';
    }

    if (!ELEVENLABS_API_KEY) {
      throw new Error('ElevenLabs API key not found');
    }

    try {
      // Use ElevenLabs or OpenAI to analyze conversation
      const conversationText = this.messages
        .map(msg => `${msg.type}: ${msg.text}`)
        .join('\n');

      // This would typically use a separate AI service for analysis
      const response = await fetch(`${ELEVENLABS_BASE_URL}/feedback`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'xi-api-key': ELEVENLABS_API_KEY,
        },
        body: JSON.stringify({
          conversation: conversationText,
          scenario: this.config.scenario,
          mode: this.config.mode,
        }),
      });

      if (!response.ok) {
        throw new Error('Feedback generation failed');
      }

      const feedbackData = await response.json();
      return feedbackData.feedback;

    } catch (error) {
      console.error('Failed to generate feedback:', error);
      // Fallback to mock feedback if API fails
      return this.generateMockFeedback();
    }
  }

  private generateMockFeedback(): string {
    return `
**Feedback zu Ihrer Session:**

**Stärken:**
- Klare Kommunikation und gute Struktur
- Überzeugende Argumente und Beispiele
- Professionelle Ausdrucksweise

**Verbesserungsmöglichkeiten:**
- Mehr konkrete Beispiele verwenden
- Pausen für Nachfragen einbauen
- Körpersprache und Tonfall variieren

**Empfehlungen:**
- Üben Sie spezifische Szenarien wiederholt
- Arbeiten Sie an Ihrer Stimmodulation
- Bereiten Sie sich auf häufige Einwände vor

**Bewertung: ${(Math.random() * 2 + 7).toFixed(1)}/10**
`;
  }
}

// Helper function to create conversation instance
export const createConversation = (config: ConversationConfig): ElevenLabsConversation => {
  return new ElevenLabsConversation(config);
};