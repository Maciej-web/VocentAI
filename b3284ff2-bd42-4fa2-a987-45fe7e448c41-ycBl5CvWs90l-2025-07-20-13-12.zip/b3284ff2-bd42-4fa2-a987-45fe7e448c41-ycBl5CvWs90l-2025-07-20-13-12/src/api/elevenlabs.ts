// ElevenLabs Conversational AI Integration
// Full WebSocket implementation for real-time voice conversations

export interface ConversationConfig {
  agentId?: string;
  sessionId?: string;
  scenario?: string;
  mode?: 'practice' | 'coaching';
  voiceId?: string;
}

export interface ConversationMessage {
  id: string;
  timestamp: Date;
  type: 'user' | 'ai';
  text: string;
  audioUrl?: string;
  duration?: number;
}

export interface ElevenLabsError {
  message: string;
  code?: string;
}

export class ElevenLabsConversation {
  private sessionId: string;
  private messages: ConversationMessage[] = [];
  private isConnected: boolean = false;
  private websocket: WebSocket | null = null;
  private apiKey: string;
  private conversationId: string | null = null;
  
  // Event callbacks
  private onMessageCallback?: (message: ConversationMessage) => void;
  private onErrorCallback?: (error: ElevenLabsError) => void;
  private onConnectCallback?: () => void;
  private onDisconnectCallback?: () => void;

  constructor(private config: ConversationConfig) {
    this.sessionId = config.sessionId || `session_${Date.now()}`;
    this.apiKey = process.env.EXPO_PUBLIC_VIBECODE_ELEVENLABS_API_KEY || '';
    
    if (!this.apiKey) {
      throw new Error('ElevenLabs API key is required');
    }
  }

  // Event listeners
  onMessage(callback: (message: ConversationMessage) => void) {
    this.onMessageCallback = callback;
  }

  onError(callback: (error: ElevenLabsError) => void) {
    this.onErrorCallback = callback;
  }

  onConnect(callback: () => void) {
    this.onConnectCallback = callback;
  }

  onDisconnect(callback: () => void) {
    this.onDisconnectCallback = callback;
  }

  async startConversation(): Promise<void> {
    try {
      // First, create a conversation agent if not exists
      if (!this.config.agentId) {
        this.config.agentId = await this.createAgent();
      }

      // Connect to WebSocket
      await this.connectWebSocket();
      
    } catch (error) {
      console.error('Failed to start conversation:', error);
      this.onErrorCallback?.({ 
        message: 'Failed to start conversation', 
        code: 'CONNECTION_ERROR' 
      });
      throw error;
    }
  }

  private async createAgent(): Promise<string> {
    const agentConfig = {
      name: `Vocent AI ${this.config.mode} - ${this.config.scenario}`,
      prompt: this.getSystemPrompt(),
      voice: {
        voice_id: this.config.voiceId || "21m00Tcm4TlvDq8ikWAM", // Default voice
        stability: 0.5,
        similarity_boost: 0.75,
        style: 0.0,
        use_speaker_boost: true
      },
      conversation_config: {
        turn_detection: {
          type: "server_vad",
          threshold: 0.5,
          prefix_padding_ms: 300,
          silence_duration_ms: 800
        }
      }
    };

    const response = await fetch('https://api.elevenlabs.io/v1/convai/agents', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': this.apiKey,
      },
      body: JSON.stringify(agentConfig),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Failed to create agent: ${error.message || response.statusText}`);
    }

    const agent = await response.json();
    return agent.agent_id;
  }

  private getSystemPrompt(): string {
    const basePrompt = `Sie sind ein professioneller KI-Trainer für Business-Gespräche. 

WICHTIGE REGELN:
- Antworten Sie nur auf Deutsch
- Bleiben Sie professionell und höflich
- Stellen Sie relevante Nachfragen
- Geben Sie konstruktives Feedback
- Simulieren Sie realistische Gesprächssituationen

`;

    switch (this.config.scenario) {
      case 'job-interview-hr':
        return basePrompt + `Sie führen ein HR-Vorstellungsgespräch. Sie sind ein erfahrener HR-Manager und bewerten den Kandidaten fair aber kritisch. Stellen Sie typische HR-Fragen zu Motivation, Teamwork, Stärken/Schwächen etc.`;
      
      case 'salary-negotiation':
        return basePrompt + `Sie sind ein Vorgesetzter in einer Gehaltsverhandlung. Seien Sie professionell aber verhandlungsbereit. Fragen Sie nach Begründungen und Leistungen.`;
      
      case 'startup-pitch':
        return basePrompt + `Sie sind ein potentieller Investor. Stellen Sie kritische Fragen zum Geschäftsmodell, Markt, Finanzen und Team.`;
      
      case 'networking-event':
        return basePrompt + `Sie sind ein Geschäftskontakt auf einem Networking-Event. Seien Sie interessiert aber professionell distanziert.`;
      
      default:
        return basePrompt + `Führen Sie ein professionelles Business-Gespräch und passen Sie sich an die Gesprächssituation an.`;
    }
  }

  private async connectWebSocket(): Promise<void> {
    return new Promise((resolve, reject) => {
      const wsUrl = `wss://api.elevenlabs.io/v1/convai/conversation?agent_id=${this.config.agentId}`;
      
      this.websocket = new WebSocket(wsUrl, [], {
        headers: {
          'xi-api-key': this.apiKey,
        }
      });

      this.websocket.onopen = () => {
        console.log('ElevenLabs WebSocket connected');
        this.isConnected = true;
        this.onConnectCallback?.();
        resolve();
      };

      this.websocket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.handleWebSocketMessage(data);
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      this.websocket.onerror = (error) => {
        console.error('WebSocket error:', error);
        this.onErrorCallback?.({ 
          message: 'WebSocket connection error',
          code: 'WEBSOCKET_ERROR' 
        });
        reject(error);
      };

      this.websocket.onclose = (event) => {
        console.log('WebSocket closed:', event.code, event.reason);
        this.isConnected = false;
        this.onDisconnectCallback?.();
      };

      // Connection timeout
      const timeout = setTimeout(() => {
        if (!this.isConnected) {
          this.websocket?.close();
          reject(new Error('WebSocket connection timeout'));
        }
      }, 10000);

      this.websocket.onopen = () => {
        clearTimeout(timeout);
        console.log('ElevenLabs WebSocket connected');
        this.isConnected = true;
        this.onConnectCallback?.();
        resolve();
      };
    });
  }

  private handleWebSocketMessage(data: any) {
    switch (data.type) {
      case 'conversation_initiation_metadata':
        this.conversationId = data.conversation_initiation_metadata_event.conversation_id;
        console.log('Conversation started:', this.conversationId);
        break;

      case 'audio':
        // Handle AI audio response
        const audioMessage: ConversationMessage = {
          id: `msg_${Date.now()}_ai`,
          timestamp: new Date(),
          type: 'ai',
          text: '', // Will be filled by transcript
          audioUrl: `data:audio/pcm;base64,${data.audio_event.audio_base_64}`,
          duration: data.audio_event.duration_ms / 1000,
        };
        this.messages.push(audioMessage);
        this.onMessageCallback?.(audioMessage);
        break;

      case 'user_transcript':
        // Handle user speech transcription
        const userMessage: ConversationMessage = {
          id: `msg_${Date.now()}_user`,
          timestamp: new Date(),
          type: 'user',
          text: data.user_transcript_event.user_transcript,
          duration: data.user_transcript_event.duration_ms / 1000,
        };
        this.messages.push(userMessage);
        this.onMessageCallback?.(userMessage);
        break;

      case 'agent_response':
        // Update AI message with transcript
        const lastAiMessage = this.messages.filter(m => m.type === 'ai').pop();
        if (lastAiMessage) {
          lastAiMessage.text = data.agent_response_event.agent_response;
          this.onMessageCallback?.(lastAiMessage);
        }
        break;

      case 'ping':
        // Respond to ping with pong
        this.websocket?.send(JSON.stringify({ type: 'pong' }));
        break;

      case 'error':
        console.error('ElevenLabs API error:', data.error);
        this.onErrorCallback?.({ 
          message: data.error.message || 'Unknown error',
          code: data.error.code 
        });
        break;

      default:
        console.log('Unhandled message type:', data.type, data);
    }
  }

  async sendAudioChunk(audioData: ArrayBuffer): Promise<void> {
    if (!this.websocket || !this.isConnected) {
      throw new Error('WebSocket not connected');
    }

    // Convert ArrayBuffer to base64
    const base64Audio = this.arrayBufferToBase64(audioData);
    
    const message = {
      type: 'audio',
      audio_event: {
        audio_base_64: base64Audio,
      }
    };

    this.websocket.send(JSON.stringify(message));
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  getMessages(): ConversationMessage[] {
    return [...this.messages];
  }

  async endConversation(): Promise<void> {
    if (this.websocket) {
      this.websocket.close();
      this.websocket = null;
    }
    this.isConnected = false;
    this.conversationId = null;
    console.log('Conversation ended');
  }

  async generateFeedback(): Promise<string> {
    if (this.config.mode !== 'coaching' || this.messages.length === 0) {
      return '';
    }

    try {
      // Use the chat service to generate feedback  
      const chatService = await import('./chat-service');
      const { getChatResponse } = chatService;
      
      const conversationSummary = this.messages
        .map(m => `${m.type === 'user' ? 'Nutzer' : 'KI'}: ${m.text}`)
        .join('\n');

      const feedbackPrompt = `
Analysiere das folgende Business-Gespräch und gib strukturiertes Feedback:

GESPRÄCH:
${conversationSummary}

SZENARIO: ${this.config.scenario}
MODUS: ${this.config.mode}

Bitte gib detailliertes Feedback in folgender Struktur:
**Stärken:**
- [Liste der Stärken]

**Verbesserungsmöglichkeiten:**
- [Liste der Verbesserungen]

**Empfehlungen:**
- [Konkrete Empfehlungen]

**Bewertung:** [Note von 1-10]/10

Antworte nur auf Deutsch und sei konstruktiv aber ehrlich.
      `;

      const feedback = await getChatResponse(feedbackPrompt, 'anthropic');
      return feedback;

    } catch (error) {
      console.error('Failed to generate feedback:', error);
      return 'Feedback konnte nicht generiert werden. Bitte versuchen Sie es erneut.';
    }
  }

  isConnectionActive(): boolean {
    return this.isConnected && this.websocket?.readyState === WebSocket.OPEN;
  }
}

// Helper function to create conversation instance
export const createConversation = (config: ConversationConfig): ElevenLabsConversation => {
  return new ElevenLabsConversation(config);
};