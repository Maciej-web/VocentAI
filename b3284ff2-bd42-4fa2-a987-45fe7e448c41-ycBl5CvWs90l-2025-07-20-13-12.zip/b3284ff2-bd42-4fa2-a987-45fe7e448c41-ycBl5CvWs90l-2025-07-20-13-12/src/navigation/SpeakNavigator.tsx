import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { colors } from '../utils/colors';

// Screens
import { SpeakHomeScreen } from '../screens/SpeakHomeScreen';
import { PracticeScreen } from '../screens/PracticeScreen';
import { CoachingScreen } from '../screens/CoachingScreen';
import { SubscriptionScreen } from '../screens/SubscriptionScreen';

const Stack = createNativeStackNavigator();

export const SpeakNavigator = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        contentStyle: { 
          backgroundColor: colors.background.primary 
        },
        animation: 'slide_from_right',
      }}
    >
      <Stack.Screen 
        name="SpeakHome" 
        component={SpeakHomeScreen}
      />
      <Stack.Screen 
        name="Practice" 
        component={PracticeScreen}
        options={{
          presentation: 'modal',
          animation: 'slide_from_bottom',
        }}
      />
      <Stack.Screen 
        name="Coaching" 
        component={CoachingScreen}
        options={{
          presentation: 'modal',
          animation: 'slide_from_bottom',
        }}
      />
      <Stack.Screen 
        name="Subscription" 
        component={SubscriptionScreen}
      />
    </Stack.Navigator>
  );
};